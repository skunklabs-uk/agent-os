import React from 'react';
import { createRoot } from 'react-dom/client';
import { ModelsConfig } from '/home/iingenito/tmp/mission35-app-kubernetes-20261015/components/ModelsConfig';
import { I18nProvider } from '/home/iingenito/tmp/mission35-app-kubernetes-20261015/hooks/useI18n';
createRoot(document.getElementById('root')!).render(<I18nProvider><ModelsConfig embedded onClose={() => {}} /></I18nProvider>);
