import assert from 'node:assert/strict';
import { getOmpRuntime } from '/home/iingenito/tmp/mission35-app-kubernetes-20261015/lib/omp-runtime.ts';
import { GET, POST } from '/home/iingenito/tmp/mission35-app-kubernetes-20261015/app/api/auth/login/[provider]/route.ts';
import { parseCallbackInput } from '/home/iingenito/tmp/mission35-app-kubernetes-20261015/node_modules/@oh-my-pi/pi-ai/src/registry/oauth/callback-server.ts';
const runtime = await getOmpRuntime();
let received;
runtime.authStorage.oauth.login = async (_provider, ctrl) => {
 ctrl.onAuth({url:'https://auth.openai.com/oauth/authorize?synthetic=1',launchUrl:'http://localhost:1455/launch'});
 ctrl.onProgress?.('Waiting for authorization');
 received = await ctrl.onManualCodeInput();
};
const params = { params:Promise.resolve({provider:'openai-codex'}) };
const response = await GET(new Request('http://localhost/api/auth/login/openai-codex'),params);
const reader = response.body.getReader();
const first = new TextDecoder().decode((await reader.read()).value);
const auth = JSON.parse(first.split('\n').find(line => line.startsWith('data: ')).slice(6));
assert.equal(auth.url,'https://auth.openai.com/oauth/authorize?synthetic=1');
const callback = 'http://localhost:1455/auth/callback?code=synthetic-code&state=synthetic-state';
const answer = await POST(new Request('http://localhost/api/auth/login/openai-codex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:auth.token,code:callback})}),params);
assert.equal(answer.status,200);
let tail=''; while(true){ const next = await reader.read(); if(next.done)break; tail += new TextDecoder().decode(next.value); }
assert.ok(tail.includes('"type":"success"'));
assert.equal(received,callback);
assert.deepEqual(parseCallbackInput(received),{code:'synthetic-code',state:'synthetic-state'});
const replay = await POST(new Request('http://localhost/api/auth/login/openai-codex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:auth.token,code:callback})}),params);
assert.equal(replay.status,404);
console.log(JSON.stringify({realRoute:true,authorizationUrlNotLoopback:true,fullCallbackAccepted:true,nativeCodeAndStatePreserved:true,replayStatus:replay.status,pending:globalThis.__ompLoginCallbacks.size,externalOAuth:'synthetic SDK boundary only',modelRequests:0}));
process.exit(0);
