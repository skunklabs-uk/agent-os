import { join } from 'node:path';
const dir = import.meta.dir;
const enc = new TextEncoder();
const pending = new Map<string, ReadableStreamDefaultController<Uint8Array>>();
let count = 0;
const posts: unknown[] = [];
const json = (v: unknown) => Response.json(v);
const send = (c: ReadableStreamDefaultController<Uint8Array>, v: unknown) => c.enqueue(enc.encode(`data: ${JSON.stringify(v)}\n\n`));
Bun.serve({hostname:'127.0.0.1',port:30147, idleTimeout:120, async fetch(req) {
 const u = new URL(req.url);
 if (u.pathname === '/') return new Response('<!doctype html><html><head><meta charset="utf-8"></head><body><div id="root"></div><script>window.opened=[];window.open=(url)=>{window.opened.push(url);return null;};</script><script type="module" src="/ui.js"></script></body></html>',{headers:{'Content-Type':'text/html'}});
 if(u.pathname==='/ui.js')return new Response(Bun.file(join(dir,'dist/entry.js')),{headers:{'Content-Type':'text/javascript'}});
 if(u.pathname==='/api/auth/providers')return json({providers:[{id:'openai-codex',name:'OpenAI Codex',usesCallbackServer:true,loggedIn:false}]});
 if(u.pathname==='/api/auth/all-providers')return json({providers:[]});
 if(u.pathname==='/api/models-config')return json({providers:{}});
 if(u.pathname==='/api/model-roles')return json({roles:{},models:[]});
 if(u.pathname==='/api/models')return json({models:[],modelList:[],roles:{}});
 if(u.pathname==='/fixture/state')return json({posts,active:pending.size});
 if(u.pathname==='/fixture/progress') { for(const c of pending.values())send(c,{type:'progress',message:'Waiting for authorization'}); return json({ok:true}); }
 if(u.pathname==='/api/auth/login/openai-codex') {
  if(req.method==='POST') { const body=await req.json() as {token:string;code:string};posts.push(body);const c=pending.get(body.token);if(!c)return json({error:'No pending login for token'});send(c,{type:'success'});c.close();pending.delete(body.token);return json({ok:true}); }
  const token=`synthetic-${++count}`;let own:ReadableStreamDefaultController<Uint8Array>;
  return new Response(new ReadableStream({start(c){own=c;pending.set(token,c);send(c,{type:'auth',url:'https://auth.openai.com/oauth/authorize?synthetic=1',token});},cancel(){pending.delete(token);}}),{headers:{'Content-Type':'text/event-stream','Cache-Control':'no-cache'}});
 }
 return json({});
}});
console.log('OAUTH_UI_FIXTURE_READY');
