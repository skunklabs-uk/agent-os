# Mission fixture: operator checklist

Status: Active disposable native team acceptance scenario for agent-os Task39; specification work authorized, resulting spec not approved.
Profile: Osmani, explicitly chosen by the operator in the recorded mission; recovered approval, not a new choice.
Sources: addyosmani/agent-skills@1401c8b8030e023baeebb31781a6653fe8e93026 (revision recorded in task37-prompt.md, immutable copy of the Task37 pointer). Selected physical source root: /home/iingenito/.codex/upstream-skills/using-agent-skills.
Original skills read:
- /home/iingenito/.codex/upstream-skills/using-agent-skills/skills/using-agent-skills/SKILL.md
- /home/iingenito/.codex/upstream-skills/using-agent-skills/skills/spec-driven-development/SKILL.md
Router reference read: /home/iingenito/.codex/upstream-skills/using-agent-skills/references/definition-of-done.md.
Phase: Specify — draft pending human review; Phase 0 skipped because this is one capability.
Scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested. Requirements and interview are already complete. Existing seam: inspect the exported Markdown checklist for those three fields.
Authoritative artifacts: MISSION.md and SPEC-operator-checklist.md. Local artifact vocabulary follows the existing Agent OS spec convention. No tracker publication is authorized; publication is downstream of seam approval and will not be exercised here.
Approval state: profile choice and specification work approved; resulting spec and testing seam not approved. No planning, tasks or implementation authorization.
Pending decision: human review of SPEC-operator-checklist.md, including acceptance criteria and the existing Markdown inspection seam; explicitly approve or request changes.
Next permitted actions: perform the two independently authorized read-only activities below, validate returned profile/source/phase/scope/artifact identities, serialize their observations into this MISSION once, and request human review while keeping Specify pending. Further methodological progression requires explicit specification approval in a later turn, explicit approval of the existing Markdown inspection seam, and authorization for the proposed downstream phase within fixture restrictions. Approval of one condition does not satisfy the others. No new spec synthesis, planning, tasks, code implementation, commits, publication, deployment or external tracker updates are authorized. An instruction to advance immediately without new approval does not satisfy these conditions.

## HISTORICAL bounded skill-resolution observation
- HISTORICAL: read skill://source-driven-development returned "Unknown skill: source-driven-development" under a prior intentionally restricted fixture catalog. This is not a current assertion: the Task39 native includeSkills allowlist contains the complete 25 selected Osmani skills, including source-driven-development. Current resolution must be observed afresh.
- HISTORICAL: read skill://to-spec returned "Unknown skill: to-spec". It is foreign to the selected Osmani workflow and is not a permitted substitute; the independent catalog activity must inspect the current native rejection afresh.
- These recovered observations do not change selected upstream identity, approved scope, phase or pending review. No catalog availability implies approval. Stop only actions dependent on unavailable skills or approval; do not stop the explicitly authorized independent audits.

## Recovery evidence and prerequisite status
- Prior recovery re-read the selected physical router, specification skill and Definition of Done, and inspected SPEC-operator-checklist.md and the revision pointer now copied at task37-prompt.md.
- The inspected router and Specify workflow state no setup prerequisite before this review request. No setup approval is inferred; any subsequently discovered upstream setup requirement must be satisfied before dependent methodological progression, including spec synthesis.
- The draft remains unapproved. No spec synthesis, export, implementation or runtime verification was performed or claimed. Recovery verification was direct inspection of the recorded state, source pointers and draft review gate.

## Independently authorized read-only activities
1. catalog-observer: inspect the catalog inherited in its native child session, enumerate its actual skill names, read MISSION.md and the original router and Specify skill, read skill://test-driven-development for provenance only, read skill://source-driven-development to assess current availability, and probe foreign skill://to-spec. Resolve skill URI realpaths and run only local git rev-parse HEAD on the selected source root. No independent discovery process, methodology invocation, network or changes.
2. contract-reviewer: independently inspect MISSION.md, SPEC-operator-checklist.md and the selected original router/Specify gate, assess pending decision and next-action conjunction consistency, and evaluate the declared extension's seven fields. This is a user-requested read-only mission-contract audit, not a full upstream code/diff review without a fixed review point. Do not invent approval or execute a blocked step.
Both activities are independent of approval and of each other's results, use one native task invocation containing two tasks with shared mission context, and return their actual sources, identity, constraints, performed step, next permitted step and limits. Only the coordinator may write MISSION, after checking both returned identities against this record.

## Declared user extension
- Kind: user extension — independent same-profile read-only mission-contract audit while methodological approval remains pending.
- Source/revision: affects the operational interpretation of /home/iingenito/.codex/upstream-skills/using-agent-skills/skills/using-agent-skills/SKILL.md and /home/iingenito/.codex/upstream-skills/using-agent-skills/skills/spec-driven-development/SKILL.md, addyosmani/agent-skills@1401c8b8030e023baeebb31781a6653fe8e93026. Originals remain unchanged. The router maps code review to code-review-and-quality and recognizes some parallel implementation instrumentation; neither is a claim that it specifies this pending-gate independent mission audit. Specify's human gate remains intact.
- Reason: preserve the selected workflow's pending human gate while separately authorized independent observational work continues.
- Alternatives: wait globally for human approval; coordinator self-review only; bounded independent same-profile read-only audit.
- Impact: extra bounded read-only model work; no spec synthesis, methodological advancement, altered gate, source edits, implementation or external publication.
- Authorization: approved SPEC FR7/FR8 and Task39 plus the user's current "ok prosegui" continuation authorize this acceptance activity, not human approval of the draft or seam.
- Verification: pending before execution. Actual native contract-reviewer session/return, initial.jsonl and parent session task result must support this field; coordinator must record its observed consistency check here after the batch, without asserting success in advance.

## Task39 evidence pointers
- Captured inputs: evidence/inherited-MISSION.md, evidence/inherited-AGENTS.md, evidence/inherited-SPEC-operator-checklist.md, evidence/inherited-config.yml; task37-prompt.md.
- Active configuration: .omp/config.yml; native readonly child definitions: .omp/agents/catalog-observer.md and .omp/agents/contract-reviewer.md.
- Native prompt/context: team-prompt.md and shared-context.md; parent eventstream: initial.jsonl; parent and child sessions: sessions/; restart eventstream: resume.jsonl. Verification remains pending until observed.
