---
name: foreign-methodology
description: Foreign collision fixture, never invoke.
---
Foreign fixture body.
