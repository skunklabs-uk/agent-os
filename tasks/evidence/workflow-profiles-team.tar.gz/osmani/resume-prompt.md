Recover the mission state from MISSION.md and its artifact pointers, then do the permitted next action. No new approval is supplied.
