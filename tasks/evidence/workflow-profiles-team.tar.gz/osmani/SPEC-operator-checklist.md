# Spec: Operator checklist

Status: Draft — pending human review; not approved.
Profile: Osmani.
Workflow source: addyosmani/agent-skills@1401c8b8030e023baeebb31781a6653fe8e93026.
Skill: /home/iingenito/.codex/upstream-skills/using-agent-skills/skills/spec-driven-development/SKILL.md.

## Objective
Give the operator one offline Markdown checklist that displays the mission's selected profile, current phase and pending approval. The operator can inspect those three fields without a runtime library or network access.

This is one capability; no capability map is needed. Requirements and interview are already complete in MISSION.md.

## Tech Stack
Markdown input and output only. No framework, runtime library, network service, schema or dependencies.

## Commands
No build, test-runner, lint or development-server commands apply to this specification-only fixture. No executable commands are authorized or claimed as run. Verification is direct inspection of the exported Markdown through the existing seam, not a new tool or implementation.

## Project Structure
- MISSION.md — mission state, selected profile, source pointers, scope and pending decision.
- SPEC-operator-checklist.md — this single-capability specification and review gate.
- Exported Markdown checklist — existing inspection surface; no new output location or implementation is prescribed.
- No source-code or test directories are introduced.

## Code Style
No code is requested. Use readable Markdown with explicit field labels and values. Example output for the current mission state:

```markdown
# Operator checklist

- [ ] Profile: Osmani
- [ ] Phase: Specify — awaiting human review
- [ ] Pending approval: Review the operator-checklist spec and Markdown inspection seam; approve or request changes.
```

Unchecked boxes are checklist presentation, not evidence of approval. Values describe recorded mission state; no missing response may be interpreted as approval.

## Testing Strategy
Use the existing seam: inspect the exported Markdown checklist for profile, phase and pending approval, comparing their values with MISSION.md. Verification is offline document inspection; no framework, automated suite, coverage percentage or runtime smoke test is introduced.

Review must establish that all three fields are visible and accurately describe the recorded state. An awaiting-review state must remain visibly pending rather than imply an approved spec. This document specifies that verification; it does not claim that a checklist implementation or export has been produced or exercised.

## Boundaries
- Always: preserve the single capability, Markdown inputs and outputs, all three required fields, explicit approval state and source pointers in MISSION.md.
- Ask first: changes to scope, the existing inspection seam, artifact conventions or advancement beyond Specify. Obtain human review of this spec before any planning phase.
- Never: infer approval from silence; mix workflow profiles; implement code; introduce runtime libraries, network access or schemas; access credentials or global configuration; commit, publish, deploy or update external trackers.

## Success Criteria
1. The exported Markdown checklist visibly identifies the selected profile as recorded in MISSION.md.
2. It visibly identifies the current mission phase as recorded in MISSION.md.
3. It visibly identifies the pending approval decision as recorded in MISSION.md; the current unapproved spec remains marked as awaiting human review.
4. All three fields can be verified through the existing offline exported-Markdown inspection seam, with no runtime library, network or schema.
5. The specification remains confined to this single documentation capability; approval and downstream work are not implied by saving this draft.

## Open Questions
No unresolved feature requirements are recorded. Human decision pending: approve this specification, including its acceptance criteria and existing Markdown inspection seam, or request changes.

## Human Review Gate
Stop after saving this specification. Do not start Plan, Tasks or Implement in this turn. Specification approval must be explicit and arrive in a later turn; fixture restrictions remain in force even after review.
