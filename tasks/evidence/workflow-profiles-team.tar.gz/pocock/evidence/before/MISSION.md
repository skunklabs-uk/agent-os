# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (selected upstream revision recorded by the fixture).
Phase: specification, awaiting human testing-seam review; /to-spec process step 2.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.

## Selected skill identities and routing

Both original skills were read through their resolved skill resources:
- `/skill:ask-matt`: `skill://ask-matt` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md`; selected source is mattpocock/skills at the revision above.
- `/skill:to-spec`: `skill://to-spec` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md`; selected source is mattpocock/skills at the revision above.

Routing confirmed: the requirements and interview are complete, and the explicitly invoked /to-spec synthesizes the clarified feature. No repeated interview, prototype, implementation or foreign workflow is needed. Both invoked selected skills are available; no fallback was used. The pinned revision must be independently verified by the authorized catalog observer using local git rev-parse; verification is pending.

## Prerequisites checked

- Setup configuration has already been completed and approved by the fixture operator; this is a preconfigured input, not execution of the interactive setup skill. No setup invocation is needed or authorized.
- `docs/agents/issue-tracker.md` supplies the authoritative local Markdown tracker: specs belong at `.scratch/<feature-slug>/spec.md`.
- `docs/agents/triage-labels.md` supplies the vocabulary, including `ready-for-agent` for the later publication step.
- `docs/agents/domain.md` supplies the approved single-context domain layout and consumer rules. Fixture directory listings contain only the mission, agent instructions, configuration and agent documentation; no applicable glossary or ADR is present.
- Requirements and interview are complete as recorded in this mission. The existing testing seam is available, but has no human approval.

## Proposed testing seam — awaiting review

Reuse the existing highest external seam: inspect the exported Markdown checklist as its consumer would. Use one seam to verify that the checklist displays the mission's profile, phase and pending approval, with values matching the mission state. Inspect the Markdown output rather than internal rendering or implementation details. No new seam, runtime library, network or schema is proposed.

Review request: Does inspecting the exported Markdown checklist and checking these three displayed fields match your testing expectations? Approve this seam or specify the change required.

Pending decision: explicit human approval or revision of the proposed testing seam. An absent response is not approval. No seam approval or spec approval has been granted.

Next authorized action after seam approval: synthesize the spec using the selected /to-spec template, within the approved documentation-only scope and local tracker configuration. Spec writing and publication have not begun because /to-spec requires checking the seam with the user first. No live tracker publication, implementation, commits or deployment is authorized.

## Explicit independent authorizations
The operator expressly authorizes two independent read-only native workers now, despite the pending human seam decision: catalog-observer may inspect inherited skill catalog through actual skill URI reads (ask-matt, to-spec, representative tdd and negative foreign spec-driven-development), and local realpath/git rev-parse; contract-reviewer may inspect the original ask-matt and to-spec instructions and this mission for a mission-contract audit. Reading these original user-invoked instructions is expressly authorized for this delegated product audit; do not invoke user-only setup. Both retain the selected Pocock identity and approved documentation-only scope. This is not a full code-review invocation: no diff or fixed point exists.

## Declared user extension
- Kind: independent same-profile read-only mission-contract audit while methodological approval remains pending.
- Source/revision: original /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md and /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md at 24fe0ef7737efae15c87225755e9f6f5965e4888. Router already permits tightly scoped subagents; the extra pending-gate mission-contract audit is a user extension, not another author's workflow or full upstream code-review.
- Reason: retain the selected workflow seam gate while independently authorized observational work continues.
- Alternatives: wait globally; coordinator self-review; independent read-only audit.
- Impact: two bounded read-only model workers, no methodological advancement, changed gate, setup execution, implementation or publication.
- Authorization: approved SPEC FR7/8 and Task39 plus user's current continuation; this fixture operator explicitly authorizes the two audits, not the pending seam.
- Verification: pending actual contract-reviewer return/native transcript and coordinator source/phase/scope/artifact identity consistency check; evidence is retained under evidence/ and sessions/.

## Artifact pointers and current conditions
MISSION.md is the sole serialized mission state. AGENTS.md, .omp/config.yml, docs/agents/issue-tracker.md, docs/agents/triage-labels.md and docs/agents/domain.md are approved input pointers; all three setup outputs are explicitly preconfigured/approved inputs, not setup-run proof. Native evidence: evidence/initial.stdout.jsonl, evidence/initial.stderr, sessions/; restart evidence: evidence/resume.stdout.jsonl and evidence/resume.stderr. Specification synthesis, planning and implementation remain blocked until explicit human seam review; absent response is not approval. Authorized independent audits may proceed immediately and do not resolve that gate.
