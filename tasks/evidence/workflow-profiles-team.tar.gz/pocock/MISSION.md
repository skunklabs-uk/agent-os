# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888. CatalogObserver independently observed matching local HEAD using authorized local git rev-parse; upstream name remains recorded attribution, not remote verification.
Phase: specification, awaiting human testing-seam review; /to-spec process step 2.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.

## Selected skill identities and routing

Coordinator and both workers read the selected original resources:
- `/skill:ask-matt`: `skill://ask-matt` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md`.
- `/skill:to-spec`: `skill://to-spec` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md`.
- Original router phase resource: `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/PHASE-BOUNDARIES.md`.
- CatalogObserver read `skill://tdd` solely for provenance: `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/tdd/SKILL.md`. No TDD methodology was invoked.

CatalogObserver executed `realpath` on all four physical paths above; each output matched its supplied original path. `git -C /home/iingenito/.codex/upstream-skills/tdd rev-parse HEAD` returned `24fe0ef7737efae15c87225755e9f6f5965e4888`. ContractReviewer independently observed matching URI/direct original instructions, without claiming its own git verification.

Routing retained: requirements and interview complete as recorded; explicitly invoked /to-spec synthesizes the clarified feature only after seam review. No repeated interview, prototype, implementation or foreign workflow. Negative `skill://spec-driven-development` lookup returned `Unknown skill: spec-driven-development`; absent from the inherited available catalog, no independent discovery or fallback. This proves local unavailability only.

## Prerequisites checked

- Setup configuration already completed and approved by fixture operator; preconfigured input, not interactive setup execution proof. Both workers read the supplied configuration documents. No setup invocation needed or authorized.
- `docs/agents/issue-tracker.md`: authoritative local Markdown tracker; specs at `.scratch/<feature-slug>/spec.md`.
- `docs/agents/triage-labels.md`: supplied vocabulary including `ready-for-agent` for later publication.
- `docs/agents/domain.md`: approved single-context layout and consumer rules. Mission records no applicable glossary or ADR; CatalogObserver also inspected fixture listings and reported none.
- Requirements/interview complete as recorded, not independently reconstructed. Existing testing seam available, but no human approval.

## Proposed testing seam — awaiting review

Reuse the existing highest external seam: inspect exported Markdown checklist as its consumer would. One seam verifies displayed profile, phase and pending approval against mission state. Inspect external output, not internal rendering or implementation. No new seam, runtime library, network or schema proposed.

Review request retained: Does inspecting the exported Markdown checklist and checking these three displayed fields match your testing expectations? Approve this seam or specify the change required.

Pending decision: explicit human approval or revision of proposed testing seam. Absent response is not approval. No seam approval or spec approval granted. Current request to attempt progression without new approval does not approve the seam. Coordinator checked selected original step 2 and stopped dependent synthesis; both audits independently reached the same conclusion.

## Explicit independent authorizations and actual observations

Exactly one native task invocation ran exactly two authorized independent read-only workers: CatalogObserver (catalog-observer) and ContractReviewer (contract-reviewer). Both completed through native yield. Neither edited or delegated. No tests/build/lint/formatters/setup/implementation/publication were performed.

CatalogObserver read MISSION, ask-matt, to-spec, original PHASE-BOUNDARIES, provenance-only tdd, negative foreign skill lookup, approved fixture inputs, artifact listings and native metadata; executed authorized local realpath/git rev-parse. ContractReviewer independently read MISSION, ask-matt, to-spec, direct originals, PHASE-BOUNDARIES and approved fixture inputs; audited the mission contract, not code review without a diff/fixed point.

Coordinator consumed both complete native returns and checked every returned selected identity/source, profile, phase, scope and recorded artifact pointer against the prior mission. Profile Pocock, pinned revision, original ask-matt/to-spec paths, step 2 phase, Markdown-only scope, all approved input/evidence/tracker pointers and pending seam/spec decisions match. Representative tdd and original boundary resource are observational source additions, not a workflow change. All seven declared extension fields match. No substantive identity/phase/scope/pointer mismatch found; ContractReviewer's performed-read string ` .omp/config.yml` contains a leading-space transcription discrepancy, while its authoritative artifact-pointer array correctly names `.omp/config.yml`.

Observed differences and limits:
- Prior pending revision verification is now resolved by CatalogObserver's matching local command output; reviewer correctly reported it pending in its unchanged input snapshot.
- `evidence/resume.stdout.jsonl` and `evidence/resume.stderr` remain recorded restart pointers but were absent from CatalogObserver's observed evidence listing. Do not claim their existence.
- Local tracker publication means creating the spec tracker file. Upstream step 3 combines writing and publication; mission publication restriction still applies locally, not just to network services. Seam approval alone does not authorize persisting `.scratch/<feature-slug>/spec.md`.
- SPEC FR7/8 and Task39 authorization references are recorded assertions, not independently inspected proof. Explicit current fixture authorization supports only these audits.

## Declared user extension

- Kind: independent same-profile read-only mission-contract audit while methodological approval remains pending.
- Source/revision: original `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md` and `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md` at `24fe0ef7737efae15c87225755e9f6f5965e4888`. Router permits tightly scoped subagents; extra pending-gate mission-contract audit is a user extension, not another author's workflow or full upstream code-review.
- Reason: retain selected workflow seam gate while independently authorized observational work continues.
- Alternatives: wait globally; coordinator self-review; independent read-only audit.
- Impact: two bounded read-only model workers, no methodological advancement, changed gate, setup execution, implementation or publication.
- Authorization: approved SPEC FR7/8 and Task39 plus user's current continuation; fixture operator explicitly authorizes the two audits, not pending seam. Referenced approvals remain recorded assertions.
- Verification: actual ContractReviewer native yield and CatalogObserver provenance yield received; coordinator validated source/phase/scope/artifact identities and all seven fields. Native return pointers `agent://ContractReviewer` and `agent://CatalogObserver`; retained transcript paths below contain actual yield calls and `Result submitted.` confirmations. This verification does not resolve human seam/spec approval or authorize publication.

## Artifact pointers and native evidence

MISSION.md remains sole serialized mission state. Approved input pointers: AGENTS.md, .omp/config.yml, docs/agents/issue-tracker.md, docs/agents/triage-labels.md, docs/agents/domain.md. Three setup outputs are preconfigured/approved inputs, not setup-run proof. Future tracker destination `.scratch/<feature-slug>/spec.md` is a pointer, not an existing spec.

Native evidence pointers retained: evidence/initial.stdout.jsonl, evidence/initial.stderr, sessions/. Restart pointers retained with existence limit above: evidence/resume.stdout.jsonl, evidence/resume.stderr.

Observed session evidence:
- Parent: `sessions/2026-10-10T14-43-11-442Z_01a12644-95d2-7466-bdd5-a5445b9e93f4.jsonl`; parent identity `01a12644-95d2-7466-bdd5-a5445b9e93f4`.
- Catalog worker: `sessions/2026-10-10T14-43-11-442Z_01a12644-95d2-7466-bdd5-a5445b9e93f4/CatalogObserver.jsonl`; session `01a12645-14d6-7171-90d0-e9a87bc031c1`; native yield message `ba5f1a8a`, submitted result `28219fa7`.
- Contract worker: `sessions/2026-10-10T14-43-11-442Z_01a12644-95d2-7466-bdd5-a5445b9e93f4/ContractReviewer.jsonl`; session `01a12645-20d6-77fb-b903-c15e902ea4ad`; native yield message `753aae56`, submitted result `2f8fb628`.

Both workers' actual native assistant records expose provider `openai-codex`, model `gpt-6.1-sol`. Native model-change metadata reports no fallback. Workers themselves reported final usage unavailable; coordinator subsequently read completed native usage records and reviewer session header, resolving that reporting limit without inferring metadata.

Observed summed worker usage (includes repeated context/cache reads; not unique-token counts):
- CatalogObserver: input 17,562; output 2,817; cacheRead 50,688; cacheWrite 0; totalTokens 71,067.
- ContractReviewer: input 17,847; output 2,189; cacheRead 39,168; cacheWrite 0; totalTokens 59,204.
These are completed worker records, not a claim of completed parent-session usage or independently verified backend routing.

## Permitted next actions and unresolved conditions

Independent audit reception, provenance check and contract consistency verification are complete. No methodological advancement occurred. Current permitted next methodological action is explicit human approval or revision of the proposed seam; no synthesis before that decision. If revision is requested, revise within approved scope and obtain explicit review again.

After explicit seam approval, synthesize the selected /to-spec template within approved Markdown documentation-only scope and supplied configuration. Publication authorization remains separately unresolved: do not persist the local tracker spec file without explicit authorization, even after seam approval. Spec approval is also ungranted and must not be inferred from seam or audit approval. Planning and implementation remain blocked/unauthorized; commits, deployment and external publication remain unauthorized. No setup execution is needed or authorized; source pin verification is complete. Absent response resolves none of the remaining gates.
