# Mission fixture: operator checklist

Status: Active disposable acceptance scenario for agent-os #38; awaiting human testing-seam review.
Profile: pocock. Explicitly selected by the user for this separate disposable mission; no default or mixed workflow.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (selected revision recorded by the fixture).
Exact invoked skill identities:
- ask-matt: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md; frontmatter name `ask-matt`; original selected upstream skill read.
- to-spec: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md; frontmatter name `to-spec`; original selected upstream skill read.
Revision provenance: the selected revision above comes from this mission's source record; no independent checkout-revision verification was performed.
Routing: ask-matt routes clarified feature synthesis to to-spec. Requirements and interview are already complete; no new interview, prototype, implementation, or alternate methodology is needed for this requested step.
Phase: specification, paused at to-spec process step 2 (human testing-seam review), before step 3 (spec writing/publication).
Scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Authoritative artifacts: MISSION.md and the future SPEC-operator-checklist.md. Local artifact vocabulary follows the existing Agent OS spec convention. No tracker publication has been authorized; publication is downstream of seam approval and will not be exercised here. No tracker configuration or label vocabulary is supplied in this fixture; live publication remains unavailable and prohibited, without fallback or setup changes.
Proposed testing seam: reuse the single existing, highest external seam: inspect the exported Markdown checklist. Review whether its displayed profile, phase and pending approval match the mission's recorded values. For the current mission, expect `pocock`, specification awaiting testing-seam review, and human confirmation of the proposed testing seam still pending. Inspect consumer-visible Markdown only; do not test internal formatting machinery or introduce a runtime/test seam.
Approval state: explicit profile choice and invocation only. Neither testing-seam approval nor spec approval has been granted. Existing seam presence is not human approval; an absent response is not approval.
Pending decision: Does the human approve this single exported-Markdown testing seam and its three field checks, or request changes?
Next permitted action: receive the human's testing-seam review. Do not write SPEC-operator-checklist.md before that review. After explicit seam approval, synthesize the local spec using the selected to-spec template within the approved documentation scope; do not publish to a live tracker or start implementation in this fixture.
