# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (selected revision recorded by the fixture).
Phase: specification, /to-spec step 2, before human testing-seam review.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Requirements and interview are complete. Existing highest external testing seam: inspect the exported Markdown checklist and its three displayed fields. No seam approval or spec approval has been granted.
Pending decision: Human review of the existing testing seam remains unapproved. Request: Does inspecting the exported Markdown checklist for the correct profile, phase and pending approval match your testing expectations? Approval must be explicit; silence is not approval.

## Exact selected skill identity and routing

User explicitly invoked /skill:ask-matt and /skill:to-spec. Read the original selected skills, resolved through skill://:
- ask-matt: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md
- to-spec: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md
- Prerequisite reference read, not invoked: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/setup-matt-pocock-skills/SKILL.md

These identities belong to the selected mattpocock/skills revision above; no Osmani or foreign workflow was substituted. Routing confirmed: already clarified feature → explicitly requested /to-spec → review the existing highest external seam before writing the spec. No new interview, prototype, tickets or implementation is needed for this next step.

## Prerequisite check and restrictions

- Tracker configuration supplied and read: docs/agents/issue-tracker.md. Local Markdown publication convention is .scratch/<feature-slug>/spec.md.
- Triage vocabulary supplied and read: docs/agents/triage-labels.md; ready-for-agent is defined. No label has been applied.
- /ask-matt requires /setup-matt-pocock-skills before the first engineering flow. The supplied tracker and labels do not establish that setup ran; the fixture explicitly says they do not represent its execution.
- Domain-doc layout and consumer rules required by setup are missing: docs/agents/domain.md is absent from the complete fixture listing. No glossary or ADRs are present in the fixture listing. Do not invent their configuration or claim setup completion.
- Setup has not been explicitly invoked. Reading its prerequisite requirements is not invocation; do not perform its human-only setup process without explicit invocation.
- Missing setup/domain configuration blocks dependent specification work, not the review request for the existing seam. Seam review remains independently required by /to-spec step 2.
- After explicit seam approval and resolution of the setup/domain prerequisite, the next dependent step is /to-spec step 3 using its original template and the local tracker convention, subject to mission authorization. Neither approval has been inferred.
- No live tracker publication, implementation, code changes, commits, deployment, credentials, global configuration or external services are authorized. No spec or tracker artifact has been created.
