# Mission fixture: operator checklist

Profile: Pocock, explicitly selected for this separate disposable mission.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888.
Phase: specification, before human testing-seam review.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Requirements and interview are complete. Existing highest external testing seam: inspect the exported Markdown checklist and its three displayed fields. No seam approval or spec approval has been granted.
Pending decision: human testing-seam review remains unapproved.
No issue tracker configuration or triage label vocabulary is supplied. No setup changes are authorized. Live publication is prohibited.
