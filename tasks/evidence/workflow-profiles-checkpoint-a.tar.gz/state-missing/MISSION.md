# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Selected upstream revision: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (recorded source revision).
Exact selected skill identities read:
- /skill:ask-matt — /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md
- /skill:to-spec — /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md
Both were explicitly invoked by the user. Their original prerequisites were reread for this turn. No foreign workflow or fallback skill was used.

Phase: specification, testing-seam review approved; spec synthesis blocked by absent setup. No spec written or approved.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Requirements and interview are complete. Routing: ask-matt confirms to-spec as the specification step for the clarified feature; no renewed interview or implementation.

Approved existing highest external testing seam: inspect the exported Markdown checklist and verify its displayed profile, phase and pending approval against the mission state. Use this single existing seam; no internal implementation checks or new seams are proposed.
Approval evidence: the user's current instruction explicitly approves only the existing exported-Markdown testing seam recorded here. This resolves testing-seam review only; it does not approve setup, spec content, implementation or publication.

Prerequisites checked against the selected original skills:
- ask-matt requires /setup-matt-pocock-skills before the first engineering flow to configure the issue tracker, triage labels and documentation layout. Setup remains absent, as explicitly confirmed by the user.
- to-spec requires an issue tracker and triage-label vocabulary. Neither is supplied. Its publication step requires the ready-for-agent label; availability is not established.
- Setup is explicitly unauthorized. The user-only /setup-matt-pocock-skills has not been invoked. When explicitly authorized and invoked by the user, it is the upstream route for establishing the missing configuration; it must not be invoked automatically.
- Absent setup blocks dependent methodological progression, including spec synthesis, not merely tracker publication. Seam approval does not resolve this prerequisite. Publication restrictions do not supply missing configuration.

Pending decision: whether the user will explicitly authorize and invoke setup. No such approval is inferred or requested as part of this turn.
Next permitted action: retain the approved seam and remain blocked on spec synthesis. Resume the applicable to-spec synthesis step only after explicit user authorization/invocation of setup and established completion of its prerequisites: issue tracker, triage-label vocabulary (including ready-for-agent for publication), and documentation layout. No spec approval has been granted. Publication and implementation remain prohibited; neither may proceed without explicit authorization lifting its restriction. If setup remains unauthorized or incomplete, do not synthesize a spec or invoke setup; preserve this blocked state.

Restrictions: live publication and implementation are prohibited. No credentials, global configuration, other repositories, external services or trackers were accessed. Only authoritative mission state and the selected original skill files were read this turn. Only this mission-state document was updated. No issue was published, no spec was synthesized and no implementation was started.
