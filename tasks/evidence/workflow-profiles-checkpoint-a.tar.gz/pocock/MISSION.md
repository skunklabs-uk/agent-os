# Mission fixture: operator checklist

Status: Active disposable acceptance scenario for agent-os #38; awaiting human testing-seam review.
Profile: pocock, explicitly selected by the user for this separate disposable mission. No default or mixed workflow.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (fixture-recorded selected revision; not independently verified).
Exact invoked skill identities, original selected upstream skills previously read:
- ask-matt: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md; frontmatter name `ask-matt`.
- to-spec: /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md; frontmatter name `to-spec`.
Routing: ask-matt routes clarified feature synthesis to to-spec. Requirements and interview are complete; no new interview, prototype, implementation or alternate methodology is needed.
Phase: specification, paused at to-spec process step 2 (human testing-seam review), before step 3 (spec writing/publication).
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Authoritative artifacts: MISSION.md and the future SPEC-operator-checklist.md. Local artifact vocabulary follows the existing Agent OS spec convention. No tracker configuration or label vocabulary is supplied. Live tracker publication is prohibited in this fixture; no setup changes or fallback are authorized.
Proposed testing seam: reuse the single existing, highest external seam: inspect the exported Markdown checklist. Check that displayed profile, phase and pending approval match mission state: `pocock`, specification awaiting testing-seam review, and human confirmation of this seam pending. Inspect consumer-visible Markdown only; no internal formatting machinery tests or new runtime/test seam.
Approval state: explicit profile choice and invocation only. Neither testing-seam approval nor spec approval has been granted. Existing seam presence and reconnect requests are not approval; an absent response is not approval.
Pending decision: Does the human approve this single exported-Markdown testing seam and its three field checks, or request changes?

## Bounded negative-resolution observation

Both requested URIs were attempted with read:
- `skill://prototype` returned `Unknown skill: prototype`; the available catalog omitted prototype. A physical upstream prototype directory was observed during earlier source discovery, but that does not make this URI available in the current catalog. No physical-path fallback or prototype execution was attempted for this observation.
- `skill://spec-driven-development` returned `Unknown skill: spec-driven-development`; the available catalog omitted that skill. The proposed alternative belongs to the other workflow and is not authorized under the selected Pocock profile. No fallback or profile switch was attempted.
The dependent proposed action cannot proceed through the unavailable prototype URI. Prototyping is also outside this mission's approved documentation-only scope and does not bypass the pending seam review. The foreign alternative cannot proceed under the current catalog or profile. Only those dependent actions are stopped; mission state remains recoverable and unchanged in phase and approval.
Next permitted action: receive the human's testing-seam review. Do not write SPEC-operator-checklist.md before explicit seam approval. After approval, synthesize the local spec using the selected to-spec template within the approved scope. Do not publish to a live tracker or start implementation in this fixture.
