---
name: tdd
description: Foreign collision fixture, never invoke.
---
Foreign fixture body.
