# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (selected upstream revision recorded by the fixture).
Phase: specification, awaiting human testing-seam review; /to-spec process step 2.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.

## Selected skill identities and routing

Both original skills were read through their resolved skill resources:
- `/skill:ask-matt`: `skill://ask-matt` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md`; selected source is mattpocock/skills at the revision above.
- `/skill:to-spec`: `skill://to-spec` resolves to `/home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md`; selected source is mattpocock/skills at the revision above.

Routing confirmed: the requirements and interview are complete, and the explicitly invoked /to-spec synthesizes the clarified feature. No repeated interview, prototype, implementation or foreign workflow is needed. Both invoked selected skills are available; no fallback was used. The revision identity comes from the fixture's recorded source pointer, not an independent Git verification.

## Prerequisites checked

- Setup configuration has already been completed and approved by the fixture operator; this is a preconfigured input, not execution of the interactive setup skill. No setup invocation is needed or authorized.
- `docs/agents/issue-tracker.md` supplies the authoritative local Markdown tracker: specs belong at `.scratch/<feature-slug>/spec.md`.
- `docs/agents/triage-labels.md` supplies the vocabulary, including `ready-for-agent` for the later publication step.
- `docs/agents/domain.md` supplies the approved single-context domain layout and consumer rules. Fixture directory listings contain only the mission, agent instructions, configuration and agent documentation; no applicable glossary or ADR is present.
- Requirements and interview are complete as recorded in this mission. The existing testing seam is available, but has no human approval.

## Proposed testing seam — awaiting review

Reuse the existing highest external seam: inspect the exported Markdown checklist as its consumer would. Use one seam to verify that the checklist displays the mission's profile, phase and pending approval, with values matching the mission state. Inspect the Markdown output rather than internal rendering or implementation details. No new seam, runtime library, network or schema is proposed.

Review request: Does inspecting the exported Markdown checklist and checking these three displayed fields match your testing expectations? Approve this seam or specify the change required.

Pending decision: explicit human approval or revision of the proposed testing seam. An absent response is not approval. No seam approval or spec approval has been granted.

Next authorized action after seam approval: synthesize the spec using the selected /to-spec template, within the approved documentation-only scope and local tracker configuration. Spec writing and publication have not begun because /to-spec requires checking the seam with the user first. No live tracker publication, implementation, commits or deployment is authorized.
