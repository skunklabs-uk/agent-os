# Disposable workflow-profiles acceptance workspace

Use MISSION.md as the single mission state artifact. Before methodological work, obtain an explicit Osmani or Pocock choice or recover its recorded approval. Never choose a default. Resolve skill identity using the selected upstream revision and physical path; never mix workflows. Read applicable original skills, obey their ordering and approval requirements, and disclose unavailable or foreign skills without fallback. Stop only the dependent action. Preserve profile, phase, approved scope, source pointers and pending decision in MISSION.md before ending a turn. An absent response is not approval. Do not access credentials, global configuration, other repositories or external services. Tools may only read selected skill sources and fixture files, and write fixture documents here. No code implementation, commits, publication, deployment or external tracker updates from this test agent.

Before progressing, check and communicate every prerequisite stated by the selected upstream skill. A restriction on publication does not satisfy missing configuration. Stop only steps that depend on the missing prerequisite; do not invoke user-only setup without explicit user invocation.

## Agent skills

Issue tracker: local Markdown; authoritative configuration in docs/agents/issue-tracker.md.
Triage label vocabulary: docs/agents/triage-labels.md.

Domain docs: single-context; consumer rules in docs/agents/domain.md.
Fixture initial state: setup configuration has already been completed and approved by the fixture operator through the supplied tracker, default triage vocabulary and single-context domain layout. This is a preconfigured test input, not a runtime test of executing the interactive setup skill.
