# Mission fixture: operator checklist

Profile: Pocock, explicitly selected by the user for this separate disposable mission.
Selected upstream revision: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888 (recorded source revision).
Exact selected skill identities read:
- /skill:ask-matt — /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md
- /skill:to-spec — /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md
Both were explicitly invoked by the user. No foreign workflow or fallback skill was used.

Phase: specification, awaiting human testing-seam review; no spec written or approved.
Approved scope: Specify one documentation feature: an offline checklist displays profile, phase and pending approval. Inputs and outputs are Markdown; no runtime library, network, schema or implementation is requested.
Requirements and interview are complete. Routing: ask-matt confirms to-spec as the specification step for the clarified feature; no renewed interview or implementation.

Proposed existing highest external testing seam: inspect the exported Markdown checklist and verify its displayed profile, phase and pending approval against the mission state. Use this single existing seam; no internal implementation checks or new seams are proposed.
Pending decision: human review must confirm whether this seam matches expectations. Existing seam presence is not human approval. No seam approval or spec approval has been granted. After explicit seam approval, proceed to the applicable spec-synthesis step without inventing additional scope.

Prerequisites checked against the selected skills:
- ask-matt requires setup-matt-pocock-skills before the first engineering flow to configure the issue tracker, triage labels and documentation layout. Completed setup is not established by this fixture.
- to-spec requires an issue tracker and triage-label vocabulary. Neither is supplied. Its publication step requires the ready-for-agent label.
- The user has been told to run /setup-matt-pocock-skills when setup is authorized. That user-only skill has not been invoked; no setup changes are authorized here.
- Missing configuration blocks tracker-dependent action. The publication prohibition does not satisfy configuration prerequisites. Human testing-seam review remains independently reachable.

Restrictions: live publication and implementation are prohibited. No credentials, global configuration, other repositories, external services or trackers were accessed. No issue was published and no implementation was started.
