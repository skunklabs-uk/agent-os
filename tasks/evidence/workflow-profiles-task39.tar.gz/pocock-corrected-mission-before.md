# Mission fixture: delegated operator checklist audit

Profile: pocock; explicitly selected and approved by the fixture operator.
Sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888; physical upstream repository /home/iingenito/.codex/upstream-skills/tdd.
Router: skill://ask-matt. Phase skill: skill://to-spec.
Phase: Specification — awaiting human testing-seam review.
Approved scope: Documentation-only offline checklist showing profile, phase and pending approval. Requirements/interview complete. For Task39 the operator authorizes two concurrent independent read-only checks: eligibility of next methodological step and consistency of the existing checklist; coordinator records observations serially. No code, spec synthesis, planning, publishing, setup execution, credentials or external services.
Authoritative pointers: MISSION.md and CHECKLIST.md; docs/agents/issue-tracker.md, docs/agents/triage-labels.md, docs/agents/domain.md.
Approval state: profile and read-only checks approved. Spec and testing seam not approved. Pending decision: human review of the recorded phase gate. No silence or child result may supply approval.
Setup configuration is complete and approved as explicit fixture input: local Markdown tracker, default triage vocabulary and single-context domain layout; this is not runtime execution of setup.
Next permitted action: request the applicable human phase review and perform the two independent authorized read-only checks. Methodological progression remains blocked until all applicable upstream prerequisites and human approvals are satisfied. Implementation/publication remains prohibited.

## Declared user extension: parallel acceptance observation
Affected sources: mattpocock/skills@24fe0ef7737efae15c87225755e9f6f5965e4888, selected router ask-matt and phase skill to-spec. Their methodological order and phase gates are unchanged; they do not prescribe this exact native audit fixture.
Reason: approved SPEC-workflow-profiles requirements5/7/8 and Task39 require observable delegation and unrelated authorized progress while a methodological gate is blocked.
Alternatives: serial observation would not prove actual concurrency; a custom coordinator would add unjustified scope/complexity; invoking another author's workflow is prohibited.
Impact: two read-only native children, selected model/provider, concurrency limit2, no shared writes or additional upstream phase. Coordinator alone updates this artifact after return.
Authorization: user-approved spec/plan/Task39 and explicit continuation on2026-10-10. This fixture input authorizes observation only, not phase-gate bypass.
Verification: actual native parent/child journals, inherited skill paths and pinned revisions, overlapping child execution, independent checklist completion, persisted pending gate and separate recovery turn; outcomes pending execution.

Use only approvals and prerequisites stated by the selected applicable upstream phase. Cite the selected source for each methodological gate. Treat fixture scope restrictions separately. Do not turn an unapproved future artifact into a precondition for creating that artifact, or optional absent glossary/ADR files into a mandatory creation step. Validate returned next actions against the original sources and explicitly reject invented gates.
