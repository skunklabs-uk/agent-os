# Existing operator checklist

Profile: osmani
Phase: Specify — awaiting human spec review
Pending approval: human review of the recorded phase gate
