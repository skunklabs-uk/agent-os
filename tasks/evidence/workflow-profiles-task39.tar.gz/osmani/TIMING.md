# Native journal timing observation

Derived by read-only inspection of actual native journals; no delays or simulated sessions. Intervals run from first completed tool operation to completed native yield, using outer journal timestamps.

- IndependentObserver.jsonl: 2026-10-10T14:40:27.238000+00:00 to 2026-10-10T14:41:18.189000+00:00; source `../sessions-osmani/2026-10-10T14-39-51-649Z_01a12641-8961-76c6-bdf7-9c18b876663d/IndependentObserver.jsonl`.
- GateObserver.jsonl: 2026-10-10T14:40:27.028000+00:00 to 2026-10-10T14:41:23.529000+00:00; source `../sessions-osmani/2026-10-10T14-39-51-649Z_01a12641-8961-76c6-bdf7-9c18b876663d/GateObserver.jsonl`.

Their observed active-session intervals overlap for 50.951 seconds. This proves overlapping child execution in this batch, not CPU parallelism or progress beyond gates.

Runtime boundary note: one original Pocock recovery called xd://report_issue; local auto-QA metadata shows that report was pushed. That recovery is excluded from the passing set. Subsequent runs disable native dev.autoqa and PI_AUTO_QA process-local override. Existing global configuration is unchanged. No claim of wire-level destination auditing is made.
