# Native journal timing observation

Derived by read-only inspection of actual native journals; no delays or simulated sessions. Intervals run from first completed tool operation to completed native yield, using outer journal timestamps.

- IndependentObserver.jsonl: 2026-10-10T14:42:34.587000+00:00 to 2026-10-10T14:43:20.093000+00:00; source `../sessions-pocock/2026-10-10T14-41-46-938Z_01a12643-4bba-72d2-8cac-15fce5557719/IndependentObserver.jsonl`.
- GateObserver.jsonl: 2026-10-10T14:42:36.240000+00:00 to 2026-10-10T14:43:34.955000+00:00; source `../sessions-pocock/2026-10-10T14-41-46-938Z_01a12643-4bba-72d2-8cac-15fce5557719/GateObserver.jsonl`.

Their observed active-session intervals overlap for 43.853 seconds. This proves overlapping child execution in this batch, not CPU parallelism or progress beyond gates.

Runtime boundary note: one original Pocock recovery called xd://report_issue; local auto-QA metadata shows that report was pushed. That recovery is excluded from the passing set. Subsequent runs disable native dev.autoqa and PI_AUTO_QA process-local override. Existing global configuration is unchanged. No claim of wire-level destination auditing is made.
