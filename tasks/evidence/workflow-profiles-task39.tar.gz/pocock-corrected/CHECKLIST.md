# Existing operator checklist

Profile: pocock
Phase: Specification — awaiting human testing-seam review
Pending approval: human review of the recorded phase gate
