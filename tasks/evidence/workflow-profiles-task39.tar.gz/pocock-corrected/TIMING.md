# Native corrected batch timing

Read-only coordinator observation of actual outer native journal timestamps, from first completed tool result to native yield completion. This is recorded evidence to verify, not simulated input.

- IndependentObserver.jsonl: 2026-10-10T14:51:50.957000+00:00 to 2026-10-10T14:53:06.548000+00:00; journal `../sessions-pocock-corrected/2026-10-10T14-51-07-745Z_01a1264b-da60-7775-a41a-49f42a93d8c4/IndependentObserver.jsonl`; relevant raw lines 11 and 41.
- GateObserver.jsonl: 2026-10-10T14:51:53.232000+00:00 to 2026-10-10T14:53:07.257000+00:00; journal `../sessions-pocock-corrected/2026-10-10T14-51-07-745Z_01a1264b-da60-7775-a41a-49f42a93d8c4/GateObserver.jsonl`; relevant raw lines 13 and 40.

Observed intersection: 73.316 seconds. No claim of CPU parallelism, continuous tool activity or progress beyond approvals.
