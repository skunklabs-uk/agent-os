import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { connect } from 'node:net';
import { join } from 'node:path';

export function control(run, message) {
  return new Promise((resolve, reject) => {
    const socket = connect(join(run, 'control.sock'));
    let text = '';
    socket.setTimeout(15_000, () => socket.destroy(new Error('Native control deadline')));
    socket.once('connect', () => socket.write(JSON.stringify(message) + '\n'));
    socket.on('data', bytes => { text += bytes.toString(); });
    socket.once('error', reject);
    socket.once('end', () => {
      try { const response = JSON.parse(text); assert.equal(response.ok, true, response.error); resolve(response.value); }
      catch (error) { reject(error); }
    });
  });
}

// Parent calls this inside JS Eval with its actual `browser` global.
// No puppeteer dependency, browser launch, fake route, simulated app status or model invocation.
export async function prepareBrowserProof(browser, run) {
  const manifest = JSON.parse(await readFile(join(run, 'ready.json'), 'utf8'));
  assert.ok(Date.now() < manifest.deadline - 10_000, 'Proof deadline has expired');
  const assertion = (await readFile(manifest.assertionFile, 'utf8')).trim();
  const tab = await browser.open({ name: 'mission35-actual-next', url: 'about:blank', headed: false,
    allowed_domains: ['127.0.0.1'], viewport: { width: 390, height: 844 }, timeout: 10, persist: true });
  await tab.emulate({ headers: { 'cf-access-jwt-assertion': assertion } });
  await tab.goto(manifest.url, { wait_until: 'domcontentloaded', timeout: 15 });
  const exactButton = label => `aria/${label}`;
  const waitFor = async (predicate, reason, milliseconds = 12_000) => {
    const deadline = Math.min(Date.now() + milliseconds, manifest.deadline - 4000);
    while (Date.now() < deadline) {
      if (await predicate()) return;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(reason);
  };
  const buttons = {
    reconnect: exactButton('Ricollega sessione'), refusal: exactButton('Rifiuta azione'),
    editor: exactButton('Invia risposta'), approve: exactButton('Approva questo piano'),
    open: 'text/Apri richieste (',
  };
  await waitFor(async () => (await tab.text('h1')).includes('Controllo della missione'), 'Actual mission surface not rendered');
  assert.ok((await tab.text('main')).includes(manifest.sessionId));
  await waitFor(() => tab.isEnabled(buttons.reconnect), 'Original ensure_session control is unavailable');
  const initial = await control(run, { op: 'http-log' });
  assert.equal(initial.filter(item => item.method === 'POST').length, 0, 'Rendering must not POST');

  return {
    tab, manifest,
    async visual(width) {
      await tab.emulate({ viewport: { width, height: width === 390 ? 844 : 1180 } });
      const geometry = await tab.run(({ page }) => page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth,
      })));
      assert.ok(geometry.scroll <= geometry.client, `Horizontal overflow at ${width}`);
      return { width, geometry, observation: await tab.observe() };
    },
    async reconnect() {
      const before = (await control(run, { op: 'http-log' })).filter(item => item.method === 'POST').length;
      await tab.click(buttons.reconnect);
      await waitFor(async () => (await tab.text('h2')).includes('Osservazione: aggiornata'), 'Native ensure_session did not become live');
      const posts = (await control(run, { op: 'http-log' })).filter(item => item.method === 'POST');
      assert.equal(posts.length, before + 1, 'Reconnect must submit exactly one original HTTP command');
      const submitted = posts.at(-1);
      assert.equal(submitted.path, `/api/agent/${manifest.sessionId}`);
      assert.equal(submitted.body.type, 'ensure_session');
      assert.equal(submitted.body.sessionId, manifest.sessionId);
      assert.equal(submitted.status, 200);
      return control(run, { op: 'checks' });
    },
    async seed(method) {
      const result = await control(run, { op: 'seed', method });
      await waitFor(() => tab.isEnabled(buttons.open), 'Pending native request not observed by original UI');
      if (!await tab.isVisible('[role="dialog"][aria-label="Decisioni dell’incarico"]')) {
        await tab.click(buttons.open);
      }
      await waitFor(() => tab.isVisible('[role="dialog"][aria-label="Decisioni dell’incarico"]'), 'Original decision dialog not visible');
      await waitFor(async () => (await tab.text('main')).includes(result.request.id), 'Exact pending native request not shown in reopened dialog');
      return result;
    },
    async answer(method) {
      const label = method === 'confirm' ? buttons.refusal : method === 'editor' ? buttons.editor : buttons.approve;
      if (method === 'editor') await tab.fill('label/Testo della risposta', 'Native editor answer — disposable');
      await waitFor(() => tab.isEnabled(label), 'Native answer control disabled');
      await tab.click(label);
      await waitFor(async () => !(await tab.isVisible('[role="dialog"][aria-label="Decisioni dell’incarico"]')), 'Original answer dialog did not close');
      return control(run, { op: 'verify', method });
    },
    async staleAndReconnect() {
      const posts = (await control(run, { op: 'http-log' })).filter(item => item.method === 'POST').length;
      // Real auth rejection at the original route, not a fake wrapper/status response.
      await tab.emulate({ headers: { 'cf-access-jwt-assertion': 'invalid-proof-assertion' } });
      await waitFor(async () => (await tab.text('h2')).includes('Osservazione: non aggiornata'), 'Real 401 did not make observation stale');
      assert.equal(await tab.isEnabled(buttons.reconnect), false);
      await tab.emulate({ headers: { 'cf-access-jwt-assertion': assertion } });
      await waitFor(async () => (await tab.text('h2')).includes('Osservazione: aggiornata'), 'Original polling did not reconnect after valid Access assertion');
      assert.equal((await control(run, { op: 'http-log' })).filter(item => item.method === 'POST').length, posts, 'Read reconnect must not POST');
      return { realAuthFailureStale: true, pollReconnectWithoutPost: true };
    },
    async observer() {
      const result = await control(run, { op: 'observer' });
      await waitFor(async () => (await tab.text('main')).includes('La sessione è observer'), 'Real observer authority not reflected in UI');
      assert.equal(await tab.isEnabled(buttons.reconnect), false);
      return result;
    },
    // Parent closes the tab and saves its screenshot/credential-redacted evidence BEFORE invoking finish.
    async finish() { return control(run, { op: 'finish' }); },
  };
}

// Uses the same real production surface and synthetic Access boundary as the ordinary proof.
// Parent chooses the answer delay, records disabled baseline controls and closes the tab before finish.
export async function prepareBootstrapProof(browser, run) {
  const proof = await prepareBrowserProof(browser, run);
  const { tab, manifest } = proof;
  const exactButton = label => `aria/${label}`;
  const buttons = {
    reconnect: exactButton('Ricollega sessione'),
    refusal: exactButton('Rifiuta azione'),
    confirm: exactButton('Conferma azione'),
    abort: exactButton('Interrompi incarico'),
    open: 'text/Apri richieste (',
    close: exactButton('Chiudi vista, senza rispondere'),
    query: exactButton('Consulta questa ricevuta'),
  };
  const dialog = '[role="dialog"][aria-label="Decisioni dell’incarico"]';
  const waitFor = async (predicate, reason, milliseconds = 12_000) => {
    const deadline = Math.min(Date.now() + milliseconds, manifest.deadline - 4000);
    while (Date.now() < deadline) {
      if (await predicate()) return;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(reason);
  };
  const enabled = async selector => await tab.isVisible(selector) && await tab.isEnabled(selector);
  const inspect = async () => {
    const refusalEnabled = await enabled(buttons.refusal);
    const confirmEnabled = await enabled(buttons.confirm);
    const abortEnabled = await enabled(buttons.abort);
    const queryEnabled = await tab.run(({ page }) => page.evaluate(() => {
      const work = document.querySelector('[aria-label="Ricevuta: Lavoro"]');
      const buttons = [...(work ?? document).querySelectorAll('button')];
      const query = buttons.find(button => button.textContent === 'Consulta questa ricevuta');
      return Boolean(query && !query.disabled);
    }));
    const dialogVisible = await tab.isVisible(dialog);
    const ui = await tab.run(({ page }) => page.evaluate(() => {
        const sections = [...document.querySelectorAll('main > section')];
        const receipts = sections.find(section => section.querySelector('h2')?.textContent === 'Ricevute e risultati');
        const receiptRows = [...(receipts?.querySelectorAll('p') ?? [])].flatMap(row => {
          const commandId = row.querySelector('code')?.textContent?.trim();
          if (!commandId) return [];
          const text = row.textContent?.trim() ?? '';
          const status = text.slice(text.indexOf(commandId) + commandId.length).match(/^\s*·\s*([a-z_]+)/)?.[1] ?? null;
          return [{ commandId, status, text }];
        });
        const requestButtons = [...document.querySelectorAll('[aria-label="Richieste vive"] button')];
        return {
          observation: sections.find(section => section.querySelector('h2')?.textContent?.startsWith('Osservazione:'))?.textContent?.trim() ?? null,
          receiptText: receipts?.textContent?.trim() ?? null,
          receipts: receiptRows,
          pendingRequestIds: requestButtons.map(button => (button.textContent ?? '').split(' · ').slice(1).join(' · ')),
          selectedRequestId: requestButtons.find(button => button.getAttribute('aria-pressed') === 'true')?.textContent?.split(' · ').slice(1).join(' · ') ?? null,
        };
    }));
    const native = await control(run, { op: 'startup-state' });
    // Observation only: disabled controls are the expected evidence on the unfixed baseline.
    return { answerEnabled: refusalEnabled, refusalEnabled, confirmEnabled, abortEnabled, queryEnabled, dialogVisible, ui, native };
  };
  let started = false;
  return {
    tab, manifest, visual: proof.visual, inspect,
    async start() {
      assert.equal(started, false, 'Do not replay the initial startup command');
      started = true;
      await tab.click(buttons.reconnect);
      let native;
      await waitFor(async () => {
        native = await control(run, { op: 'startup-state' });
        return Boolean(native.request?.id);
      }, 'Actual session_start did not expose its native pending confirm');
      await waitFor(async () => (await tab.text('main')).includes(native.request.id), 'Native startup request not observed by original UI');
      if (!await tab.isVisible(dialog)) await tab.click(buttons.open);
      await waitFor(() => tab.isVisible(dialog), 'Original startup decision dialog not visible');
      return inspect();
    },
    async answer(confirmed = false) {
      assert.equal(typeof confirmed, 'boolean', 'Native confirm requires a boolean response');
      if (!await tab.isVisible(dialog)) {
        await waitFor(() => enabled(buttons.open), 'Original pending startup request cannot be reopened');
        await tab.click(buttons.open);
        await waitFor(() => tab.isVisible(dialog), 'Original startup decision dialog did not reopen');
      }
      const button = confirmed ? buttons.confirm : buttons.refusal;
      await waitFor(() => enabled(button), 'Native startup answer control disabled');
      await tab.click(button);
      await waitFor(async () => !(await tab.isVisible(dialog)), 'Original startup answer dialog did not close');
      return control(run, { op: 'verify-startup', action: 'answer', confirmed });
    },
    async interrupt() {
      // The actual modal covers the interruption button; dismissing it does not answer the request.
      if (await tab.isVisible(dialog)) await tab.click(buttons.close);
      await waitFor(() => enabled(buttons.abort), 'Native startup interruption control disabled or unauthorized');
      await tab.click(buttons.abort);
      return control(run, { op: 'verify-startup', action: 'abort' });
    },
    async finish() { return control(run, { op: 'finish-startup' }); },
  };
}
