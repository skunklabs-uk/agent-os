import assert from 'node:assert/strict';
import { join } from 'node:path';
import { installNativeHttpTrialBudget } from './native-http-trial-budget';

// Intentional module-loading boundary: the private environment and fetch denial
// must precede native imports; the registry is constructed before the budget.
const initialFetch = globalThis.fetch;
let physical = 0;
const server = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch(request) {
  physical++;
  assert.equal(request.method, 'GET');
  assert.equal(new URL(request.url).pathname, '/v1/models');
  return Response.json({ data: [{ id: 'late-bound-native-fixture', object: 'model' }] });
}});
const baseUrl = `http://127.0.0.1:${server.port}/v1`;
const { ModelRegistry } = await import('../node_modules/@oh-my-pi/pi-coding-agent/src/config/model-registry.ts');
const { AuthStorage } = await import('../node_modules/@oh-my-pi/pi-ai/src/auth-storage.ts');
const { wrapFetchForExtraCa } = await import('../node_modules/@oh-my-pi/pi-utils/src/tls-fetch.ts');
const auth = await AuthStorage.create(join(process.env.HOME!, 'fixture-auth.db'));
const modelsPath = join(process.env.HOME!, 'models.yml');
await Bun.write(modelsPath, JSON.stringify({ providers: { 'late-binding-proof': {
  api: 'openai-completions', apiKey: 'synthetic-local-fixture', baseUrl,
  discovery: { type: 'openai-models-list' },
} } }));
let dispatches = 0;
let budgetInstalled = false;
let closeBudget = () => {};
const lateBound = Object.assign((input: RequestInfo | URL, init?: RequestInit) => {
  assert.ok(budgetInstalled, 'Registry transport used before the HTTP guard was installed');
  dispatches++;
  return globalThis.fetch(input, init);
}, { preconnect: globalThis.fetch.preconnect });
try {
  const registry = new ModelRegistry(auth, modelsPath, {
    cacheDbPath: join(process.env.HOME!, 'fixture-models.db'), fetch: wrapFetchForExtraCa(lateBound),
  });
  assert.equal(physical, 0);
  assert.equal(dispatches, 0);
  const budget = installNativeHttpTrialBudget({ modelUrls: [`${baseUrl}/responses`], maxRequests: 30, durationMs: 1000 });
  closeBudget = budget.close;
  budgetInstalled = true;
  await registry.refreshProvider('late-binding-proof', 'online');
  assert.equal(registry.find('late-binding-proof', 'late-bound-native-fixture')?.id, 'late-bound-native-fixture');
  assert.equal(dispatches, 1);
  assert.equal(physical, 1);
  assert.equal(budget.snapshot().admitted, 0, 'Discovery GET must not consume model POST allowance');
  console.log(JSON.stringify({ mode: 'registry-late-binding', nativeDiscoveryObserved: true,
    constructorBeforeBudget: true, physicalDiscoveryGets: physical, guardedDispatches: dispatches,
    budget: budget.snapshot(), paidRequests: 0 }));
} finally {
  closeBudget(); globalThis.fetch = initialFetch; auth.close(); server.stop(true);
}
