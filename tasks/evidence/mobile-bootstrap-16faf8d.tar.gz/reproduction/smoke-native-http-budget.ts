import assert from 'node:assert/strict';
import { installNativeHttpTrialBudget } from './native-http-trial-budget';
const mode = process.argv[2];
process.env.PI_CODEX_WEBSOCKET = '0';
let physical = 0;
let modelPhysical = 0;
let refreshPhysical = 0;
const fixtureToken = ['fixture', Buffer.from(JSON.stringify({ 'https://api.openai.com/auth': { chatgpt_account_id: 'local-fixture' } })).toString('base64url'), 'fixture'].join('.');
const server = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch(request) {
  if (request.method === 'POST') physical++;
  const path = new URL(request.url).pathname;
  if (request.method === 'POST' && path === '/backend-api/codex/responses') modelPhysical++;
  if (request.method === 'POST' && path === '/oauth/token') {
    refreshPhysical++;
    return Response.json({ access_token: fixtureToken, refresh_token: 'synthetic-refresh', expires_in: 3600 });
  }
  if (mode === 'stream-deadline') return new Response(new ReadableStream({
    start(controller) { controller.enqueue(new TextEncoder().encode('data: fixture\n\n')); },
  }), { headers: { 'content-type': 'text/event-stream' } });
  if (mode === 'deadline') return new Promise<Response>(resolve => setTimeout(() => resolve(new Response('late')), 500));
  if (mode === 'retry') return new Response('fixture unavailable', { status: 503 });
  if (mode === 'sse-error') return new Response('data: '+JSON.stringify({ type: 'error', error: { code: 'server_error', message: 'fixture failure' } })+'\n\n', { headers: { 'content-type': 'text/event-stream' } });
  return Response.json({ reached: true });
}});
const url = `http://127.0.0.1:${server.port}/backend-api/codex/responses`;
const refreshUrl = `http://127.0.0.1:${server.port}/oauth/token`;
const budget = installNativeHttpTrialBudget({ modelUrls: [url], nonModelPostUrls: [refreshUrl],
  maxRequests: mode === 'sse-error' || mode === 'binding-refresh' ? 2 : 30,
  durationMs: mode === 'deadline' ? 25 : mode === 'stream-deadline' ? 100 : 10_000 });
try {
  // Intentional import boundary: install the fetch budget before the native
  // provider captures globalThis.fetch in transportFetch.
  const { transportFetch } = await import('../node_modules/@oh-my-pi/pi-ai/src/utils/transport-fetch.ts');
  const { buildModel } = await import('../node_modules/@oh-my-pi/pi-catalog/src/build.ts');
  const model = buildModel({ provider: 'openai-codex', api: 'openai-codex-responses', id: 'gpt-6.1-sol', name: 'Fixture', baseUrl: url.slice(0,-10), reasoning: true, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 4096 });
  const transport = transportFetch(model, undefined);
  assert.equal(typeof transport.preconnect, typeof fetch.preconnect);
  if (mode === 'cap') {
    await transport(url, { method: 'GET' });
    assert.equal(budget.snapshot().admitted, 0);
    for (let n=0;n<30;n++) assert.equal((await transport(url, { method: 'POST', body: 'fixture' })).status, 200);
    await assert.rejects(transport(url, { method: 'POST', body: 'fixture' }));
    assert.equal(physical, 30); assert.equal(budget.snapshot().admitted, 30); assert.equal(budget.snapshot().blocked, 1);
  } else if (mode === 'deadline') {
    await assert.rejects(transport(url, { method: 'POST', body: 'fixture' }));
    assert.equal(budget.snapshot().reason, 'deadline');
    await assert.rejects(transport(url, { method: 'POST', body: 'fixture' }));
    assert.ok(physical <= 1); assert.equal(budget.snapshot().admitted, 1);
  } else if (mode === 'stream-deadline') {
    const response = await transport(url, { method: 'POST', body: 'fixture' });
    const reader = response.body!.getReader();
    try {
      const first = await reader.read();
      assert.equal(new TextDecoder().decode(first.value), 'data: fixture\n\n');
      await assert.rejects(reader.read());
      assert.equal(budget.snapshot().reason, 'deadline');
      await assert.rejects(fetch(url, { method: 'POST', body: 'fixture' }));
      assert.equal(modelPhysical, 1); assert.equal(budget.snapshot().admitted, 1);
    } finally { reader.releaseLock(); }
  } else if (mode === 'binding-refresh') {
    const { authProviders } = await import('../node_modules/@oh-my-pi/pi-catalog/src/compat/auth.ts');
    const { createRefresh } = await import('../node_modules/@oh-my-pi/pi-ai/src/registry/engine/refresh.ts');
    const policy = authProviders().find(policy => policy.id === 'openai-codex')!;
    const rule = policy.refresh;
    if (rule?.kind !== 'request') throw new Error('Native request refresh policy required');
    const refresh = createRefresh({ ...policy, refresh: { ...rule,
      token: { ...rule.token, url: { value: refreshUrl } } } })!;
    const credentials = await refresh({ access: fixtureToken, refresh: 'synthetic-refresh', expires: 0 });
    assert.equal(credentials.access, fixtureToken);
    assert.ok(credentials.expires > Date.now());
    assert.equal(refreshPhysical, 1); assert.equal(budget.snapshot().admitted, 0);
    await Promise.all([fetch(url, { method: 'POST', body: 'global' }), transport(url, { method: 'POST', body: 'native' })]);
    assert.equal(modelPhysical, 2); assert.equal(budget.snapshot().admitted, 2);
    await assert.rejects(fetch(url, { method: 'POST', body: 'blocked' }));
    assert.equal(modelPhysical, 2); assert.equal(budget.snapshot().reason, 'request-cap');
  } else if (mode === 'unqualified') {
    await assert.rejects(fetch(`${refreshUrl}?extra=1`, { method: 'POST', body: 'fixture' }));
    await assert.rejects(transport(new URL('/unqualified', url), { method: 'POST', body: 'fixture' }));
    assert.equal(physical, 0); assert.equal(budget.snapshot().admitted, 0);
    assert.equal(budget.snapshot().blocked, 2); assert.equal(budget.snapshot().reason, 'unknown-endpoint');
  } else if (mode === 'retry' || mode === 'sse-error') {
    const { completeSimple } = await import('../node_modules/@oh-my-pi/pi-ai/src/index.ts');
    const token = fixtureToken;
    const result = await completeSimple(model, { messages: [{ role: 'user', content: 'fixture request', timestamp: Date.now() }] }, { apiKey: token, providerRetryWait: async () => {}, codexSseMaxAttempts: mode === 'retry' ? 3 : 1 });
    console.log(JSON.stringify({ nativeFixtureDiagnostic: true, mode, physical, budget: budget.snapshot(), error: result.errorMessage }));
    assert.equal(result.stopReason, 'error');
    assert.equal(physical, mode === 'retry' ? 3 : 2);
    assert.equal(budget.snapshot().admitted, physical);
    if (mode === 'sse-error') {
      assert.equal(budget.snapshot().blocked, 1);
      assert.equal(budget.snapshot().reason, 'request-cap');
    }
  } else throw new Error('Unknown smoke mode');
  console.log(JSON.stringify({ mode, physicalHttpPostRequests: physical, physicalModelPostRequests: modelPhysical,
    physicalRefreshPostRequests: refreshPhysical, ...budget.snapshot(), provider: 'local-loopback-fixture', paidRequests: 0 }));
} finally { budget.close(); server.stop(true); }
