// Solo trial privato: installare prima degli import SDK/app, poi rimuovere.
// Conta dispatch HTTP ammesse, non fatturazione o pacchetti TCP.
export function installNativeHttpTrialBudget(options: {
  modelUrls: string[];
  maxRequests?: number;
  durationMs?: number;
  nonModelPostUrls?: string[];
}) {
  const original = globalThis.fetch;
  const maxRequests = options.maxRequests ?? 30;
  const durationMs = options.durationMs ?? 900_000;
  if (!Number.isInteger(maxRequests) || maxRequests < 1 || !Number.isFinite(durationMs) || durationMs <= 0) throw new Error("Invalid trial bounds");
  const endpoint = (value: string | URL) => {
    const url = new URL(value);
    if (url.username || url.password || url.search || url.hash) throw new Error("Ambiguous trial endpoint");
    return `${url.origin}${url.pathname}`;
  };
  // Membership comes from runtime-qualified endpoints, not a static literal table.
  const models = new Set(options.modelUrls.map(endpoint));
  if (!models.size) throw new Error("Explicit model endpoints required");
  const nonModels = new Set((options.nonModelPostUrls ?? []).map(endpoint));
  const abort = new AbortController();
  let admitted = 0;
  let blocked = 0;
  let failed = 0;
  let startedAt: number | undefined;
  let timer: NodeJS.Timeout | undefined;
  let reason: "request-cap" | "deadline" | "unknown-endpoint" | "closed" | undefined;
  const stop = (why: typeof reason) => {
    reason ??= why;
    clearTimeout(timer);
    abort.abort(new Error("Trial HTTP budget stopped"));
  };
  const wrapped = async (input: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]): Promise<Response> => {
    const url = new URL(input instanceof Request ? input.url : String(input));
    const method = (init?.method ?? (input instanceof Request ? input.method : "GET")).toUpperCase();
    const address = `${url.origin}${url.pathname}`;
    if (method !== "POST") return original(input, init);
    if ((!models.has(address) && !nonModels.has(address)) || url.username || url.password || url.search || url.hash) {
      blocked++; stop("unknown-endpoint"); throw new Error("Unqualified outbound POST during trial");
    }
    if (nonModels.has(address)) return original(input, { ...init, redirect: "error", keepalive: false });
    const now = performance.now();
    if (reason || admitted >= maxRequests || (startedAt !== undefined && now - startedAt >= durationMs)) {
      blocked++; stop(reason ?? (admitted >= maxRequests ? "request-cap" : "deadline"));
      throw new Error("Trial HTTP budget exhausted");
    }
    if (startedAt === undefined) {
      startedAt = now;
      timer = setTimeout(() => stop("deadline"), durationMs);
      timer.unref?.();
    }
    // Synchronous admission before delegation: concurrent callers cannot overshoot.
    admitted++;
    const signal = init?.signal ?? (input instanceof Request ? input.signal : undefined);
    try {
      return await original(input, { ...init, signal: signal ? AbortSignal.any([signal, abort.signal]) : abort.signal,
        redirect: "error", keepalive: false });
    } catch (error) { failed++; throw error; }
  };
  // Preserve Bun's native static API, including preconnect, without cloning requests.
  for (const key of Reflect.ownKeys(original)) {
    if (typeof key === "string" && ["length", "name", "prototype", "arguments", "caller"].includes(key)) continue;
    Object.defineProperty(wrapped, key, Object.getOwnPropertyDescriptor(original, key)!);
  }
  globalThis.fetch = wrapped as typeof fetch;
  return {
    snapshot: () => ({ admitted, blocked, failed, remaining: maxRequests - admitted, reason: reason ?? null,
      elapsedMs: startedAt === undefined ? 0 : Math.round(performance.now() - startedAt), maxRequests, durationMs }),
    close: () => stop("closed"),
  };
}
