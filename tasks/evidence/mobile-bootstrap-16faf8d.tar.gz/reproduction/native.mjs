import assert from 'node:assert/strict';
import { createServer as httpServer } from 'node:http';
import { createServer } from 'node:net';
import { readFile, writeFile, rm } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const run = process.env.PROOF_RUN, source = process.env.PROOF_SOURCE;
assert.ok(run && source);
const scenario = process.env.PROOF_SCENARIO ?? 'ordinary';
assert.ok(['ordinary', 'startup'].includes(scenario));
const url = 'http://127.0.0.1:30455';
const require = createRequire(join(source, 'package.json'));
const { generateKeyPair, exportJWK, SignJWT } = await import(pathToFileURL(require.resolve('jose')).href);
const { publicKey, privateKey } = await generateKeyPair('RS256');
const jwk = { ...await exportJWK(publicKey), kid: 'disposable-rs256', alg: 'RS256', use: 'sig' };
const team = process.env.OMP_WEB_ACCESS_TEAM_DOMAIN;
const assertion = await new SignJWT({ type: 'app', email: 'proof@example.invalid' }).setProtectedHeader({ alg: 'RS256', kid: jwk.kid })
  .setIssuer(team).setAudience(process.env.OMP_WEB_ACCESS_AUD).setSubject('disposable-browser-proof').setIssuedAt().setExpirationTime('5m').sign(privateKey);
await writeFile(join(run, 'assertion.txt'), assertion, { mode: 0o600 });
const originalFetch = globalThis.fetch.bind(globalThis);
const outbound = [];
let jwksFetches = 0;
// Only remote JWKS transport is synthetic. jwtVerify, route authorization, host/origin checks and all app bodies stay original.
globalThis.fetch = async (input, options) => {
  const target = new URL(typeof input === 'string' || input instanceof URL ? String(input) : input.url);
  const method = (options?.method ?? (input instanceof Request ? input.method : 'GET')).toUpperCase();
  if (target.href === `${team}/cdn-cgi/access/certs` && method === 'GET') {
    jwksFetches++;
    return Response.json({ keys: [jwk] });
  }
  if (target.origin !== url || target.username || target.password) {
    outbound.push({ host: target.hostname, method });
    throw new Error('External transport denied by disposable proof fetch boundary');
  }
  // Fail on redirects rather than letting a loopback response bypass this boundary.
  return originalFetch(input, { ...options, redirect: 'error' });
};
// Install the transport boundary before Next or any SDK/model registry module can capture fetch.
const next = require('next');
const startupExtensionPath = join(process.env.PI_CODING_AGENT_DIR, 'extensions', 'mission35-startup.js');
const startup = { starts: 0, nativeStarted: false, nativeSettled: false, nativeValue: undefined,
  readiness: false, readinessError: null, request: null, wrapper: null, abortCalls: 0, abortSettled: 0 };
if (scenario === 'startup') {
  globalThis.__mission35StartupProof = startup;
  await writeFile(startupExtensionPath, `export default function (pi) {
  pi.on('session_start', async (_event, ctx) => {
    const proof = globalThis.__mission35StartupProof;
    proof.starts++;
    proof.nativeStarted = true;
    proof.startedAt = Date.now();
    proof.nativeSessionId = ctx.sessionManager.getSessionId();
    console.log('[mission35-proof] native session_start awaiting confirm');
    const value = await ctx.ui.confirm('Native startup prerequisite', 'Resolve only this disposable startup prerequisite. No model inference or implementation is authorized.');
    proof.nativeValue = value;
    proof.nativeSettled = true;
    proof.settledAt = Date.now();
    console.log('[mission35-proof] native startup confirm settled: ' + JSON.stringify(value));
  });
}
`, { mode: 0o600 });
}
const importSource = name => import(pathToFileURL(join(source, 'lib', name)).href);
const { ensureMissionSession } = await importSource('mission-session.ts');
const { getRpcSession } = await importSource('rpc-manager.ts');
const sdkPackage = JSON.parse(await readFile(join(source, 'node_modules/@oh-my-pi/pi-coding-agent/package.json'), 'utf8'));
const { SessionManager } = await import(pathToFileURL(join(source, 'node_modules/@oh-my-pi/pi-coding-agent', sdkPackage.exports['.'].import)).href);
const cwd = process.env.AGENT_OS_MISSION_CWD;
const proposalPath = join(cwd, 'reviewed-plan.md');
const proposalContent = '# Disposable reviewed plan\n\nNo implementation and no model inference are requested.\n';
await writeFile(proposalPath, proposalContent);
execFileSync('git', ['init', '-q', cwd]);
execFileSync('git', ['-C', cwd, 'config', 'user.name', 'Disposable Proof']);
execFileSync('git', ['-C', cwd, 'config', 'user.email', 'proof@example.invalid']);
const binding = await ensureMissionSession(process.env.AGENT_OS_MISSION_ID, cwd);
assert.equal(binding.status, 'bound');
const planPath = join(cwd, 'tasks', 'plan.md');
function plan(role = 'executor') {
  return ['# Disposable mission', '', '**Status:** Active', '**Mission:** https://github.com/example/disposable/issues/35',
    '**Coordinator:** proof-owner', '**Coordinator session:** proof-coordinator', `**Provider role:** ${role}`,
    `**Provider session:** ${binding.sessionId}`, '**Permitted scope:** disposable-browser-proof',
    '**Permitted commands:** ' + (role === 'observer' ? 'observe' : 'observe, ensure_session, answer, abort'),
    '**Method:** Pocock', '**Phase:** browser-proof', '', '## Assignment', 'Only this disposable repository and native decisions.', ''].join('\n');
}
await writeFile(planPath, plan());
execFileSync('git', ['-C', cwd, 'add', '.']);
execFileSync('git', ['-C', cwd, 'commit', '-qm', 'Disposable native browser proof']);
const manager = await SessionManager.open(binding.sessionFile, undefined);
// Public native journal API: runtime rehydrates real plan mode and installs its ORIGINAL proposal handler at start.
manager.appendModeChange('plan', { planFilePath: proposalPath, workflow: 'iterative', reentry: true });
await manager.ensureOnDisk();

const httpLog = [];
let app, server, control, closing = false;
const connections = new Set();
const pending = new Map();
const results = {};
const abort = new AbortController();
const deadline = Number(process.env.PROOF_DEADLINE);
const timer = setTimeout(() => void cleanup(124), Math.max(1, deadline - Date.now() - 2200));
process.on('SIGTERM', () => void cleanup(143)); process.on('SIGINT', () => void cleanup(130));
async function cleanup(code = 0) {
  if (closing) return;
  closing = true; clearTimeout(timer); abort.abort();
  for (const socket of connections) socket.destroy();
  control?.close(); server?.closeAllConnections(); server?.close();
  try { await getRpcSession(binding.sessionId)?.shutdown(); } catch {}
  try { await app?.close(); } catch {}
  await writeFile(join(run, 'native-results.json'), JSON.stringify({ scenario, results, httpLog, jwksFetches, outbound, code,
    startup: { starts: startup.starts, nativeStarted: startup.nativeStarted, nativeSettled: startup.nativeSettled,
      nativeValue: startup.nativeValue, readiness: startup.readiness, readinessError: startup.readinessError } }, null, 2), { mode: 0o600 });
  await rm(join(run, 'assertion.txt'), { force: true });
  if (scenario === 'startup') await rm(startupExtensionPath, { force: true });
  // Launcher's owned process-group TERM/KILL is the hard bound for a stuck native shutdown.
  process.exit(code);
}
async function request(path, body, headers = {}) {
  const response = await originalFetch(url + path, { method: body ? 'POST' : 'GET', headers: {
    'cf-access-jwt-assertion': assertion, ...(body ? { 'content-type': 'application/json' } : {}), ...headers,
  }, ...(body ? { body: JSON.stringify(body) } : {}), signal: abort.signal, redirect: 'error' });
  return { status: response.status, body: await response.json() };
}
async function state() {
  const response = await request(`/api/agent/${binding.sessionId}`);
  assert.equal(response.status, 200); return response.body;
}
function context(authority) {
  const { missionId, sessionId, scope, revision, sourceRevision } = authority;
  return { missionId, sessionId, scope, revision, sourceRevision };
}
function wrapper() {
  const live = getRpcSession(binding.sessionId);
  assert.ok(live?.isAlive(), 'Original bound native wrapper not live; use UI ensure_session first');
  assert.equal(live.inner.model ?? null, null, 'Actual SDK model must remain unset; no model stub is accepted');
  assert.equal(live.inner.queuedMessageCount, 0);
  assert.equal(live.inner.modelRegistry.getAvailable().length, 0, 'Credential-free registry must offer no authenticated model');
  return live;
}
// Observation only: do not await readiness or submit the initial ensure command here.
async function startupState() {
  assert.equal(scenario, 'startup');
  const live = getRpcSession(binding.sessionId);
  if (live?.isAlive()) {
    wrapper();
    if (!startup.wrapper) {
      startup.wrapper = live;
      // Count invocations while delegating unchanged to the actual native SDK abort.
      const nativeAbort = live.inner.abort.bind(live.inner);
      live.inner.abort = async (...args) => {
        startup.abortCalls++;
        await nativeAbort(...args);
        startup.abortSettled++;
      };
      void live.waitUntilReady().then(() => { startup.readiness = true; },
        error => { startup.readinessError = error instanceof Error ? error.message : String(error); });
    }
    assert.equal(live, startup.wrapper, 'Bootstrap must keep the same original native wrapper');
    const pendingRequest = live.getPendingUiSnapshot().find(item => item.method === 'confirm');
    if (pendingRequest) {
      assert.equal(pendingRequest.sessionId, binding.sessionId);
      assert.equal(pendingRequest.scope, 'disposable-browser-proof');
      assert.ok(pendingRequest.revision && pendingRequest.sourceRevision);
      if (startup.request) assert.equal(pendingRequest.id, startup.request.id);
      startup.request = pendingRequest;
    }
  }
  const ensures = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'ensure_session');
  const original = ensures[0];
  const ensureResult = original ? await request(`${original.path}?commandId=${encodeURIComponent(original.body.commandId)}`) : null;
  return { request: startup.request, nativeStarted: startup.nativeStarted, nativeSettled: startup.nativeSettled,
    nativeValue: startup.nativeValue ?? null, nativeSessionId: startup.nativeSessionId ?? null, startupStarts: startup.starts,
    readiness: startup.readiness, readinessError: startup.readinessError, nativeAbortCalls: startup.abortCalls,
    nativeAbortSettled: startup.abortSettled, nativeIdle: live?.isAlive() ? !live.isRunning() : null,
    sessionId: binding.sessionId, ensureCommandId: original?.body.commandId ?? null,
    ensureResult: ensureResult?.body ?? null, ensureHttpStatus: ensureResult?.status ?? null, httpLog };
}

async function verifyStartup(message) {
  assert.equal(scenario, 'startup');
  assert.ok(['answer', 'abort'].includes(message.action));
  let snapshot = await startupState();
  assert.equal(snapshot.startupStarts, 1, 'Exactly one native session_start must run');
  assert.equal(snapshot.nativeSessionId, binding.sessionId);
  assert.ok(snapshot.request, 'Observe the real startup request before resolving it');
  const ensures = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'ensure_session');
  assert.equal(ensures.length, 1, 'Initial ensure must be queried, never replayed');
  if (message.action === 'abort') {
    const submitted = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'abort').at(-1);
    assert.ok(submitted, 'Actual UI abort POST missing');
    assert.equal(submitted.status, 200);
    assert.equal(snapshot.nativeAbortCalls, 1, 'Abort must reach the original native SDK exactly once');
    assert.equal(snapshot.nativeAbortSettled, 1);
    const receipt = await request(`${submitted.path}?commandId=${encodeURIComponent(submitted.body.commandId)}`);
    assert.equal(receipt.status, 200);
    assert.ok(['acknowledged', 'completed'].includes(receipt.body.status));
    results.startupAbort = { originalNativeAbortVerified: true, receipt: receipt.body,
      startupStillPending: !snapshot.nativeSettled, initialReceiptQueriedWithoutReplay: true };
    return { ...snapshot, verification: results.startupAbort };
  }
  assert.equal(typeof message.confirmed, 'boolean');
  for (let count = 0; count < 100 && !(snapshot.nativeSettled && snapshot.readiness && snapshot.ensureResult?.status === 'completed'); count++) {
    await new Promise(resolve => setTimeout(resolve, 25));
    snapshot = await startupState();
  }
  assert.equal(snapshot.nativeSettled, true, 'Native confirm future did not settle');
  assert.equal(snapshot.nativeValue, message.confirmed);
  assert.equal(snapshot.readiness, true, 'Original wrapper readiness did not resolve');
  assert.equal(snapshot.ensureHttpStatus, 200);
  assert.equal(snapshot.ensureResult?.commandId, snapshot.ensureCommandId);
  assert.equal(snapshot.ensureResult?.status, 'completed', 'Initial ensure receipt did not complete');
  const answered = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'answer' && item.body.requestId === snapshot.request.id).at(-1);
  assert.ok(answered); assert.equal(answered.status, 200);
  assert.deepEqual(context(answered.body), context(snapshot.request));
  assert.equal(answered.body.response.confirmed, message.confirmed);
  assert.equal(wrapper().getPendingUiSnapshot().length, 0);
  results.startupAnswer = { nativeValueVerified: true, readinessVerified: true, nativeValue: snapshot.nativeValue,
    ensureCommandId: snapshot.ensureCommandId, initialReceipt: snapshot.ensureResult, initialReceiptQueriedWithoutReplay: true };
  return { ...snapshot, verification: results.startupAnswer };
}
async function sseSnapshot() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await originalFetch(`${url}/api/agent/${binding.sessionId}/events`, { headers: { 'cf-access-jwt-assertion': assertion }, signal: controller.signal, redirect: 'error' });
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/event-stream/);
    const reader = response.body.getReader();
    let text = '';
    while (!text.includes('\n\n')) { const chunk = await reader.read(); assert.equal(chunk.done, false); text += new TextDecoder().decode(chunk.value); }
    const event = JSON.parse(text.split('\n\n')[0].replace(/^data: /, ''));
    assert.equal(event.type, 'connected'); assert.equal(event.sessionId, binding.sessionId);
    for (const request of event.pendingExtensionUiRequests) {
      assert.equal(request.sessionId, binding.sessionId); assert.equal(request.scope, 'disposable-browser-proof');
      assert.ok(request.revision && request.sourceRevision); assert.equal('planFilePath' in request, false);
    }
    controller.abort(); return event;
  } finally { clearTimeout(timeout); controller.abort(); }
}
async function command(message) {
  if (message.op === 'startup-state') return startupState();
  if (message.op === 'verify-startup') return verifyStartup(message);
  if (message.op === 'finish-startup') {
    assert.equal(scenario, 'startup');
    assert.ok(results.startupAnswer, 'Native future/readiness/initial receipt must be verified before cleanup');
    assert.equal(httpLog.filter(item => item.method === 'POST' && item.body?.type === 'ensure_session').length, 1);
    const rows = wrapper().inner.sessionManager.getEntries();
    assert.equal(rows.filter(item => item.type === 'message' && ['user', 'assistant'].includes(item.message?.role)).length, 0);
    assert.equal(outbound.filter(item => item.method === 'POST').length, 0, 'Unexpected external model dispatch');
    assert.ok(jwksFetches > 0, 'Real Access verifier must fetch synthetic key material');
    results.zeroInference = true;
    setTimeout(() => void cleanup(0), 100);
    return { completed: true, nativeStartupVerifiedBeforeTeardown: true };
  }
  const live = message.op === 'http-log' || message.op === 'finish' ? undefined : wrapper();
  if (message.op === 'http-log') return httpLog;
  if (message.op === 'seed') {
    assert.ok(['confirm', 'editor', 'plan_review'].includes(message.method));
    assert.equal((await state()).pendingRequests.length, 0, 'Complete current request before seeding another');
    let ui;
    // Public wrapper binding callback exposes its ORIGINAL native ExtensionUiContext, without private access or a fake wrapper.
    live.bindToolUiContext(original => { ui = original; });
    let answer;
    if (message.method === 'confirm') answer = ui.confirm('Native refusal proof', 'Reject only this disposable action.');
    else if (message.method === 'editor') answer = ui.editor('Native editor proof', 'Disposable prefill');
    else {
      assert.equal(live.inner.getPlanModeState()?.enabled, true);
      const handler = live.inner.peekPlanProposalHandler();
      assert.equal(typeof handler, 'function', 'Public native model-unset session has no original proposal handler');
      answer = handler('Disposable reviewed plan');
    }
    const entry = { settled: false, value: undefined, promise: undefined };
    entry.promise = Promise.resolve(answer).then(value => { entry.settled = true; entry.value = value; return value; });
    pending.set(message.method, entry);
    for (let count = 0; count < 100; count++) {
      const snapshot = await state();
      const request = snapshot.pendingRequests.find(item => item.method === message.method);
      if (request) {
        entry.request = request;
        const first = await sseSnapshot(), reconnected = await sseSnapshot();
        assert.equal(first.pendingExtensionUiRequests[0].id, request.id);
        assert.equal(reconnected.pendingExtensionUiRequests[0].id, request.id);
        return { request, sseReconnect: true };
      }
      await new Promise(resolve => setTimeout(resolve, 25));
    }
    throw new Error('Original public API did not produce a pending request');
  }
  if (message.op === 'verify') {
    const entry = pending.get(message.method); assert.ok(entry?.settled, 'Native promise has not settled; receipt alone is insufficient');
    if (message.method === 'confirm') assert.equal(entry.value, false);
    if (message.method === 'editor') assert.equal(entry.value, 'Native editor answer — disposable');
    if (message.method === 'plan_review') {
      assert.match(entry.value.content.map(item => item.text ?? '').join('\n'), /Plan approved/);
      assert.equal(live.inner.getPlanModeState(), undefined);
      assert.equal(live.inner.peekPlanProposalHandler(), undefined);
      assert.equal(live.inner.getPlanReferencePath(), proposalPath);
      assert.equal(live.inner.sessionManager.getEntries().filter(item => item.type === 'mode_change').at(-1).mode, 'none');
      assert.equal(await readFile(proposalPath, 'utf8'), proposalContent);
    }
    const snapshot = await state(); assert.equal(snapshot.pendingRequests.length, 0);
    const answerPost = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'answer' && item.body.requestId === entry.request.id).at(-1);
    assert.ok(answerPost); assert.equal(answerPost.status, 200); assert.equal(answerPost.body.scope, entry.request.scope);
    const replay = await request(`/api/agent/${binding.sessionId}`, answerPost.body);
    assert.equal(replay.status, 200); assert.equal(replay.body.status, 'acknowledged');
    const stale = await request(`/api/agent/${binding.sessionId}`, { ...answerPost.body, commandId: `stale-${message.method}` });
    assert.equal(stale.status, 409); assert.equal(stale.body.status, 'rejected');
    results[message.method] = { nativeValueVerified: true, idempotentReplay: true, staleRequestRejected: true };
    return results[message.method];
  }
  if (message.op === 'checks') {
    const snapshot = await state(); const authority = snapshot.authority; assert.ok(authority);
    const posts = httpLog.filter(item => item.method === 'POST' && item.body?.type === 'ensure_session');
    assert.ok(posts.length >= 1); const original = posts[0];
    assert.equal(original.path, `/api/agent/${binding.sessionId}`); assert.equal(original.body.sessionId, binding.sessionId);
    assert.deepEqual(context(original.body), context(authority));
    const replay = await request(original.path, original.body);
    assert.equal(replay.status, 200); assert.equal(replay.body.status, 'completed');
    assert.equal(getRpcSession(binding.sessionId), live, 'Ensure replay must retain original native runtime');
    const wrongGet = await request('/api/agent/other-session'); assert.equal(wrongGet.status, 403);
    const wrongSse = await originalFetch(`${url}/api/agent/other-session/events`, { headers: { 'cf-access-jwt-assertion': assertion }, signal: abort.signal }); assert.equal(wrongSse.status, 403); await wrongSse.text();
    const wrongScope = await request(`/api/agent/${binding.sessionId}`, { ...context(authority), scope: 'other-scope', commandId: 'wrong-scope', type: 'ensure_session' }); assert.equal(wrongScope.status, 409);
    const crossSite = await request(`/api/agent/${binding.sessionId}`, undefined, { origin: 'https://other.invalid', 'sec-fetch-site': 'cross-site' }); assert.equal(crossSite.status, 403);
    const outside = await request('/api/settings'); assert.equal(outside.status, 403);
    results.boundary = { originalEnsure: true, ensureIdempotence: true, wrongBinding: true, wrongSseBinding: true, wrongScope: true, crossSite: true, outsideMission: true };
    return results.boundary;
  }
  if (message.op === 'observer') {
    assert.equal(results.plan_review?.nativeValueVerified, true, 'Approval must be verified before changing authority/teardown');
    await writeFile(planPath, plan('observer'));
    const snapshot = await state(); assert.equal(snapshot.authority.providerRole, 'observer');
    const response = await request('/api/agent/new', { ...context(snapshot.authority), commandId: 'observer-ensure', type: 'ensure_session' });
    assert.equal(response.status, 403); assert.equal(response.body.status, 'rejected');
    results.observer = { actualAuthority: true, mutationRejected: true }; return results.observer;
  }
  if (message.op === 'finish') {
    assert.ok(results.confirm && results.editor && results.plan_review && results.boundary && results.observer, 'Missing actual proof phases');
    const liveNow = wrapper();
    const rows = liveNow.inner.sessionManager.getEntries();
    assert.equal(rows.filter(item => item.type === 'message' && ['user', 'assistant'].includes(item.message?.role)).length, 0);
    assert.equal(outbound.filter(item => item.method === 'POST').length, 0, 'Unexpected non-loopback model dispatch');
    assert.ok(jwksFetches > 0, 'Real verifier must have fetched signed key material');
    results.zeroInference = true;
    setTimeout(() => void cleanup(0), 100); return { completed: true, nativeApprovalVerifiedBeforeTeardown: true };
  }
  throw new Error('Unknown preparation control operation');
}
try {
  app = next({ dev: false, dir: source, hostname: '127.0.0.1', port: 30455 });
  await app.prepare();
  const handler = app.getRequestHandler();
  server = httpServer((req, res) => {
    const item = { method: req.method, path: req.url, status: undefined, body: undefined };
    httpLog.push(item);
    let body = ''; req.on('data', bytes => { body += bytes.toString(); }); req.on('end', () => { if (body) { try { item.body = JSON.parse(body); } catch {} } });
    res.once('finish', () => { item.status = res.statusCode; });
    void handler(req, res);
  });
  server.on('connection', socket => { connections.add(socket); socket.once('close', () => connections.delete(socket)); });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(30455, '127.0.0.1', resolve); });
  control = createServer(socket => {
    connections.add(socket); socket.once('close', () => connections.delete(socket));
    let text = ''; socket.on('data', bytes => {
      text += bytes.toString(); if (!text.includes('\n')) return;
      socket.removeAllListeners('data');
      void command(JSON.parse(text.split('\n')[0])).then(value => socket.end(JSON.stringify({ ok: true, value }) + '\n'), error => socket.end(JSON.stringify({ ok: false, error: error.message }) + '\n'));
    });
    socket.on('error', () => socket.destroy());
  });
  await new Promise((resolve, reject) => { control.once('error', reject); control.listen(join(run, 'control.sock'), resolve); });
  const manifest = { url, run, scenario, sessionId: binding.sessionId, repository: cwd, missionId: process.env.AGENT_OS_MISSION_ID,
    assertionFile: join(run, 'assertion.txt'), deadline, sha: process.env.PROOF_SOURCE_SHA, buildId: process.env.PROOF_BUILD_ID, buildFilesSha256: process.env.PROOF_BUILD_FILES_SHA256 };
  await writeFile(join(run, 'ready.json'), JSON.stringify(manifest), { mode: 0o600 });
} catch (error) { console.error(error.stack); await cleanup(1); }
