import assert from 'node:assert/strict';
import { installNativeHttpTrialBudget } from './native-http-trial-budget';
const launchedAt = Date.now();
let modelPosts = 0;
let refreshPosts = 0;
let sdkExpired = false;
// Same lifecycle as the original preflight: timer installed before native imports.
// OS timeout is installed by the parent before Bun starts, including this bootstrap.
const sdkTimer = setTimeout(() => {
  sdkExpired = true;
  console.log(JSON.stringify({ phase: 'sdk-launch-deadline', elapsedMs: Date.now() - launchedAt,
    modelPosts, refreshPosts, sdkExpired }));
}, 1500);
const server = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch(request) {
  assert.equal(request.method, 'POST');
  if (new URL(request.url).pathname === '/oauth/token') {
    refreshPosts++;
    console.log(JSON.stringify({ phase: 'native-refresh-before-first-model', modelPosts, refreshPosts }));
    return new Promise<Response>(() => {});
  }
  modelPosts++;
  throw new Error('No model request is authorized in launch-deadline proof');
}});
const origin = `http://127.0.0.1:${server.port}`;
const budget = installNativeHttpTrialBudget({ modelUrls: [`${origin}/responses`],
  nonModelPostUrls: [`${origin}/oauth/token`], maxRequests: 30, durationMs: 5000 });
try {
  // Intentional loading boundary: timer, private profile and transport guard precede native capture.
  const { authProviders } = await import('../node_modules/@oh-my-pi/pi-catalog/src/compat/auth.ts');
  const { createRefresh } = await import('../node_modules/@oh-my-pi/pi-ai/src/registry/engine/refresh.ts');
  const policy = authProviders().find(item => item.id === 'openai-codex');
  assert.ok(policy?.refresh?.kind === 'request');
  const refresh = createRefresh({ ...policy, refresh: { ...policy.refresh,
    token: { ...policy.refresh.token, url: { value: `${origin}/oauth/token` } } } });
  assert.ok(refresh);
  await refresh({ access: 'synthetic-expired-token', refresh: 'synthetic-refresh-token', expires: 0 });
  throw new Error('Held native refresh unexpectedly completed before OS deadline');
} finally { clearTimeout(sdkTimer); budget.close(); server.stop(true); }
