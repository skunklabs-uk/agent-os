// Mission35: metadata-only per default; --trial è un solo prompt SDK read-only
// sulla sessione observer, NON GO missione, ownership, esecuzione o rilascio.
// Parent soltanto, senza altro writer bound e dopo review/versione/build finali:
// PI_NATIVES_DIR=/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/natives/18.8.7 timeout --signal=KILL 900s /home/iingenito/.local/state/agent-os/remote-control/mobile-compat/bin/bun /home/iingenito/.local/state/agent-os/remote-control/mission35/handoff/preflight-native-metadata-pocock.ts --trial
// Il watchdog OS deve esistere dal lancio; quello SDK scade a 890s dal lancio,
// riservando <=10s al teardown. Parent revisiona e rimuove il file risposta
// privato e questo preload temporaneo dopo il trial; mai retry manuali/fallback.
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { chmod, mkdtemp, readFile, realpath, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, relative, sep } from "node:path";
import { promisify } from "node:util";
import type { AgentSession, AuthStorage, SessionManager, Settings } from "/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-coding-agent/src/index.ts";
import { installNativeHttpTrialBudget } from "./native-http-trial-budget.ts";
import type { FetchImpl } from "/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-utils/src/tls-fetch.ts";

const argumentsReceived = process.argv.slice(2);
const trial = argumentsReceived.length === 1 && argumentsReceived[0] === "--trial";
const launchDeadlineMs = 890_000;
const launchDeadlineAt = Date.now() + Math.max(0, launchDeadlineMs - process.uptime() * 1000);
const remainingLaunchMs = () => Math.min(launchDeadlineAt - Date.now(), launchDeadlineMs - process.uptime() * 1000);

const cwd = "/home/iingenito/projects/personal/.worktrees/agent-os-omp-coordinator";
const agentDir = "/home/iingenito/.local/state/agent-os/remote-control/mission35/agent";
const authDir = "/home/iingenito/.omp/agent";
const sessionId = "01a131c7-ecba-7000-a4fb-ff906f642f4f";
const sessionFile = join(agentDir, "sessions/-projects-personal-.worktrees-agent-os-omp-coordinator/2026-10-12T20-22-28-282Z_01a131c7-ecba-7000-a4fb-ff906f642f4f.jsonl");
const missionId = "skunklabs-uk/agent-os#35";
const upstream = "/home/iingenito/.codex/upstream-skills/ask-matt";
const pin = "24fe0ef7737efae15c87225755e9f6f5965e4888";
const customDirectories = [join(upstream, "skills/engineering"), join(upstream, "skills/productivity")];
const expectedSkills = [
  "ask-matt", "code-review", "codebase-design", "diagnosing-bugs", "domain-modeling",
  "grill-me", "grill-with-docs", "grilling", "handoff", "implement", "implement-spec",
  "improve-codebase-architecture", "pr", "prototype", "research", "retro",
  "setup-matt-pocock-skills", "tdd", "teach", "to-questionnaire", "to-spec", "to-tickets",
  "triage", "wait-what", "wayfinder", "wizard", "writing-for-agents",
].sort();
const modelSelector = "openai-codex/gpt-6.1-sol:low";
const roles = ["default", "smol", "slow", "plan", "task", "tiny"];
const run = promisify(execFile);
class Incompatibility extends Error {}
function requireInvariant(ok: unknown, invariant: string): asserts ok {
  if (!ok) throw new Incompatibility(invariant);
}
function sameNames(actual: readonly string[], expected: readonly string[]): boolean {
  return JSON.stringify([...actual].sort()) === JSON.stringify([...expected].sort());
}
interface SessionDiskSnapshot {
  sha256: string;
  persistedEntryCount: number;
  messageEntryCount: number;
  messageRoles: { user: number; assistant: number; toolResult: number; other: number };
  originalMessagePrefixSha256: string;
  modelChangeEntryCount: number;
  thinkingEntryCount: number;
  bindingEntryCount: number;
  bindingSha256: string;
}
// Contratto privato minimo del counter esistente, che questa slice non modifica.
interface NativeHttpBudgetSnapshot {
  admitted: number;
  blocked: number;
  failed: number;
  remaining: number;
  reason: "request-cap" | "deadline" | "unknown-endpoint" | "closed" | null;
  elapsedMs: number;
  maxRequests: number;
  durationMs: number;
}
interface NativeHttpBudget {
  snapshot(): NativeHttpBudgetSnapshot;
  close(): void;
}
async function diskSnapshot(originalMessageCount?: number) {
  const bytes = await readFile(sessionFile);
  const entries = bytes.toString("utf8").split("\n").filter(line => line.trim()).map(line => JSON.parse(line));
  const nativeEntries = entries.filter(entry => entry.type !== "session");
  const messages = nativeEntries.filter(entry => entry.type === "message");
  const bindings = nativeEntries.filter(entry => entry.type === "custom" && entry.customType === "agent-os-mission-binding");
  return {
    sha256: createHash("sha256").update(bytes).digest("hex"),
    persistedEntryCount: nativeEntries.length,
    messageEntryCount: messages.length,
    messageRoles: {
      user: messages.filter(entry => entry.message?.role === "user").length,
      assistant: messages.filter(entry => entry.message?.role === "assistant").length,
      toolResult: messages.filter(entry => entry.message?.role === "toolResult").length,
      other: messages.filter(entry => !["user", "assistant", "toolResult"].includes(entry.message?.role)).length,
    },
    originalMessagePrefixSha256: createHash("sha256").update(JSON.stringify(messages.slice(0, originalMessageCount ?? messages.length))).digest("hex"),
    modelChangeEntryCount: nativeEntries.filter(entry => entry.type === "model_change").length,
    thinkingEntryCount: nativeEntries.filter(entry => entry.type === "thinking_level_change").length,
    bindingEntryCount: bindings.length,
    bindingSha256: createHash("sha256").update(JSON.stringify(bindings)).digest("hex"),
  };
}

let stage = "environment";
let failure: string | undefined;
let session: AgentSession | undefined;
let manager: SessionManager | undefined;
let authStorage: AuthStorage | undefined;
let settings: Settings | undefined;
let authSettings: Settings | undefined;
let before: SessionDiskSnapshot | undefined;
let after: SessionDiskSnapshot | undefined;
let nativeEntryCountBefore: number | undefined;
let nativeEntryCountAfter: number | undefined;
let observed: Record<string, unknown> | undefined;
let sourceRole: string | undefined;
let modelDispatches = 0;
let suppressedConsoleCalls = 0;
let budget: NativeHttpBudget | undefined;
let httpSummary: NativeHttpBudgetSnapshot | undefined;
const originalFetch = globalThis.fetch;
let promptStarted = false;
let finalResponseFile: string | undefined;
let finalResponseDirectory: string | undefined;
let terminalStopReason: string | undefined;
let unsubscribe: (() => void) | undefined;
const nativeLifecycle: { end?: { isTerminal?: boolean; yielded?: boolean; awaitingAsyncWork?: boolean } } = {};
let modelBefore: { provider: string | undefined; id: string | undefined; thinking: string | undefined } | undefined;
let modelAfter: typeof modelBefore;
const successfulReads = { askMatt: 0, currentPlan: 0, boundPlan: 0, other: 0 };
const pendingReads = new Map<string, keyof typeof successfulReads>();
let abortWork: Promise<void> | undefined;
const stopTrial = () => {
  failure ??= "launch-deadline-or-operator-interrupt";
  budget?.close();
  if (session && !abortWork) {
    abortWork = session.abort({ goalReason: "internal", reason: "bounded-native-read-only-trial-stop" });
    void abortWork.catch(() => { failure ??= "native-trial-abort-failed"; });
  }
};
// Installato prima di imports/config/bootstrap, non al primo POST del counter.
const launchTimer = trial ? setTimeout(stopTrial, Math.max(0, remainingLaunchMs())) : undefined;
launchTimer?.unref();
if (trial) process.once("SIGTERM", stopTrial);
// I diagnostici arbitrari SDK non fanno parte dell'allowlist e non vengono
// serializzati, neppure nel ramo errore. Nessun contenuto/credenziale viene emesso.
const consoleNames = ["log", "info", "warn", "error", "debug"] as const;
const originalConsole = Object.fromEntries(consoleNames.map(name => [name, console[name]])) as Record<typeof consoleNames[number], typeof console.log>;
for (const name of consoleNames) console[name] = () => { suppressedConsoleCalls++; };
try {
  requireInvariant(argumentsReceived.length === 0 || trial, "unsupported-preflight-arguments");
  if (trial) {
    requireInvariant(Bun.version === "1.3.14", "qualified-bun-version-mismatch");
    requireInvariant(process.env.PI_NATIVES_DIR === "/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/natives/18.8.7", "qualified-native-directory-mismatch");
    requireInvariant(remainingLaunchMs() > 0 && !failure, "launch-deadline-exhausted");
  }
  // DirResolver cattura l'ambiente all'import. La selezione default esplicita
  // impedisce al profilo ereditato dal parent di sostituire l'agentDir privato.
  process.env.OMP_PROFILE = "";
  process.env.PI_PROFILE = "";
  process.env.PI_CODING_AGENT_DIR = agentDir;
  process.env.PI_CODEX_WEBSOCKET = "0";
  process.env.AGENT_OS_MISSION_ID = missionId;
  process.env.AGENT_OS_MISSION_CWD = cwd;
  process.chdir(cwd);
  before = await diskSnapshot();
  requireInvariant((await stat(join(authDir, "agent.db"))).isFile(), "existing-native-auth-db-required");
  const packageMetadata = JSON.parse(await readFile("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-coding-agent/package.json", "utf8"));
  requireInvariant(packageMetadata.version === "18.8.7", "installed-sdk-version-mismatch");
  const { stdout: upstreamHead } = await run("git", ["-C", upstream, "rev-parse", "HEAD"]);
  requireInvariant(upstreamHead.trim() === pin, "pocock-original-pin-mismatch");

  stage = "native-imports";
  // Eccezione import dinamici: DirResolver/env.ts congelano il profilo all'import;
  // gli import statici SDK partirebbero prima della selezione ambiente sopra.
  const sdk = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-coding-agent/src/index.ts");
  const dirs = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-utils/src/dirs.ts");
  const { lookup } = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-coding-agent/src/config/registry.ts");
  requireInvariant(dirs.getActiveProfile() === undefined && dirs.getAgentDir() === agentDir, "frozen-private-profile-mismatch");
  requireInvariant(process.cwd() === cwd, "process-cwd-mismatch");
  requireInvariant(sdk.SessionManager.getDefaultSessionDir(cwd, agentDir) === dirname(sessionFile), "native-session-directory-mismatch");
  const settingValue = (scope: Settings, id: string): unknown => {
    const handle = lookup(id);
    requireInvariant(handle, "installed-setting-handle-missing");
    return handle.get(scope);
  };
  stage = "effective-private-config";
  settings = await sdk.Settings.loadReadOnly({ cwd, agentDir });
  authSettings = await sdk.Settings.loadReadOnly({ cwd, agentDir: authDir });
  // Refuserà un auth broker configurato prima di discoverAuthStorage: nessuna
  // connessione broker, fallback, login o copia; il dir native esistente è diretto.
  requireInvariant(!settingValue(authSettings, "auth.broker.url"), "native-auth-broker-incompatible");
  requireInvariant(settingValue(settings, "retry.enabled") === false, "retry-enabled-mismatch");
  requireInvariant(settingValue(settings, "retry.maxRetries") === 0, "retry-max-retries-mismatch");
  const fallbackChains = settingValue(settings, "retry.fallbackChains");
  requireInvariant(fallbackChains && typeof fallbackChains === "object" && Object.keys(fallbackChains).length === 0, "retry-fallback-chains-mismatch");
  requireInvariant(settingValue(settings, "dev.autoqa") === false, "autoqa-mismatch");
  requireInvariant(settingValue(settings, "providers.openaiWebsockets") === "off", "private-websocket-policy-mismatch");
  for (const role of roles) requireInvariant(settings.getModelRole(role) === modelSelector, "private-model-role-mismatch");
  requireInvariant(settingValue(settings, "skills.enabled") === true, "skills-disabled");
  for (const flag of ["enableCodexUser", "enableClaudeUser", "enableClaudeProject", "enablePiUser", "enablePiProject", "enableAgentsUser", "enableAgentsProject"]) {
    requireInvariant(settingValue(settings, `skills.${flag}`) === false, "ambient-skill-source-enabled");
  }
  requireInvariant(sameNames(settingValue(settings, "skills.customDirectories") as string[], customDirectories), "private-skill-directory-mismatch");
  requireInvariant(sameNames(settingValue(settings, "skills.includeSkills") as string[], expectedSkills), "configured-catalog-mismatch");

  stage = "bound-native-session";
  manager = await sdk.SessionManager.open(sessionFile, dirname(sessionFile), undefined, { throwIfMissing: true, suppressBreadcrumb: true });
  requireInvariant(manager.getSessionId() === sessionId && manager.getCwd() === cwd && manager.getHeader()?.cwd === cwd, "bound-session-identity-mismatch");
  const entriesBefore = manager.getEntries();
  nativeEntryCountBefore = entriesBefore.length;
  const bindings = entriesBefore.filter(entry => entry.type === "custom" && entry.customType === "agent-os-mission-binding");
  requireInvariant(bindings.length === 1, "bound-marker-count-mismatch");
  const binding = bindings[0] as { data?: { missionId?: unknown; cwd?: unknown } };
  requireInvariant(binding.data?.missionId === missionId && binding.data.cwd === cwd, "bound-marker-identity-mismatch");
  requireInvariant(manager.buildSessionContext().messages.length > 0, "bound-history-missing");
  // Import statico impossibile qui: il gate importa le directory native che
  // devono essere caricate soltanto dopo la selezione del profilo sopra.
  const { readMissionAuthority } = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/lib/mission-authority.ts");
  const authority = readMissionAuthority(cwd, sessionId);
  requireInvariant(authority?.coordinatorSession === "01a139d2-93a6-704a-a1cc-570907f479a9"
    && authority.providerRole === "observer" && authority.commands.length === 1
    && authority.commands[0] === "observe" && authority.method.includes(pin), "current-source-authority-mismatch");
  sourceRole = authority.providerRole;

  stage = "existing-native-auth";
  authStorage = await sdk.discoverAuthStorage(authDir, { settings: authSettings, cwd });
  const authSource = authStorage.keys.source("openai-codex");
  requireInvariant(authSource?.kind === "oauth" || authSource?.kind === "api_key", "existing-stored-native-auth-required");
  // Policy privata reale: niente listing automatico che schedula compressioni
  // one-shot. Catalogo/URI originali restano nativi, senza overlay o cache fittizia.
  requireInvariant(settingValue(settings, "skillful") === false, "private-skill-listing-policy-mismatch");
  const metadataSettings = settings;
  // Import dinamico: tls-fetch importa env.ts; il profilo è già congelato qui.
  const { wrapFetchForExtraCa } = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-utils/src/tls-fetch.ts");
  let registryFetch: FetchImpl | undefined;
  if (trial) {
    registryFetch = (input, init) => {
      requireInvariant(budget, "native-trial-transport-before-http-budget");
      return globalThis.fetch(input, init);
    };
    registryFetch.preconnect = globalThis.fetch.preconnect;
    registryFetch = wrapFetchForExtraCa(registryFetch);
  }
  const modelRegistry = new sdk.ModelRegistry(authStorage, join(agentDir, "models.yml"), {
    settings: metadataSettings, cacheDbPath: join(agentDir, "models.db"),
    // Il constructor nativo cattura fetch: questo seam nativo mantiene TLS/CA
    // e risolve il globale solo al dispatch, DOPO qualificazione URL e counter.
    // Non fabbrica risposte e impedisce rete nel bootstrap offline del trial.
    fetch: registryFetch,
  });
  await modelRegistry.hydrateCredentialScopedModelCaches();
  const model = modelRegistry.find("openai-codex", "gpt-6.1-sol");
  requireInvariant(model && modelRegistry.hasConfiguredAuth(model), "qualified-model-unavailable-offline");
  if (trial) {
    stage = "qualify-native-http-endpoints";
    requireInvariant(model.api === "openai-codex-responses", "qualified-native-provider-api-mismatch");
    // Hydrate è local-only/offline; il registry ha un fetch late-bound sorvegliato.
    // SSE legge fetch a ogni tentativo; OAuth lo cattura durante refresh.
    // Import dinamico REQUIRED: il provider importa DirResolver/env transitivi,
    // che non devono congelarsi prima della selezione ambiente sopra.
    // Counter installato prima di createAgentSession/cattura transport/prompt.
    const { resolveCodexResponsesUrl } = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-ai/src/providers/openai-codex-responses.ts");
    const { authPolicyFor } = await import("/home/iingenito/.local/state/agent-os/remote-control/mobile-compat/port/qualification-bc/node_modules/@oh-my-pi/pi-catalog/src/compat/auth.ts");
    const refresh = authPolicyFor(model.provider)?.refresh;
    requireInvariant(refresh?.kind === "request", "native-refresh-policy-unavailable");
    const refreshValue = refresh.token.url;
    requireInvariant(typeof refreshValue.value === "string" && !refreshValue.hook && !refreshValue.encoding
      && !refreshValue.env?.length, "native-refresh-url-not-exact");
    const qualifyHttps = (value: string) => {
      const url = new URL(value);
      requireInvariant(url.protocol === "https:" && !url.username && !url.password && !url.search && !url.hash
        && !/[{}]/.test(value), "native-endpoint-not-qualified-https");
      return url.href;
    };
    const modelUrl = qualifyHttps(resolveCodexResponsesUrl(model.baseUrl));
    const refreshUrl = qualifyHttps(refreshValue.value);
    requireInvariant(modelUrl !== refreshUrl, "native-model-and-refresh-url-collision");
    requireInvariant(remainingLaunchMs() > 0 && !failure, "launch-deadline-exhausted");
    budget = installNativeHttpTrialBudget({
      modelUrls: [modelUrl], nonModelPostUrls: [refreshUrl], maxRequests: 30, durationMs: remainingLaunchMs(),
    });
  }
  stage = "native-metadata-create";
  const created = await sdk.createAgentSession({
    cwd, agentDir, authStorage, modelRegistry, settings: metadataSettings, sessionManager: manager,
    model, thinkingLevel: "low", allowSessionModelFallback: false,
    toolNames: ["read"], restrictToolNames: true,
    disableExtensionDiscovery: true, enableMCP: false, enableLsp: false, enableIrc: false,
    cacheWarming: false, skipPythonPreflight: true, autoTitle: false,
    onFirstChatDispatch: () => {
      modelDispatches++;
      // Marker osservativo: il SDK cattura l'eccezione, non è enforcement HTTP.
      if (!trial) throw new Incompatibility("unexpected-model-dispatch");
    },
  });
  session = created.session;
  requireInvariant(session.sessionId === sessionId && session.sessionManager === manager && manager.getCwd() === cwd, "created-native-identity-mismatch");
  requireInvariant(session.model?.provider === "openai-codex" && session.model.id === "gpt-6.1-sol" && session.thinkingLevel === "low", "created-model-thinking-mismatch");
  requireInvariant(created.modelFallbackMessage === undefined, "unexpected-model-fallback");
  requireInvariant(sameNames(session.getActiveToolNames(), ["read"]), "created-tool-scope-mismatch");
  requireInvariant(!created.mcpManager && created.extensionsResult.extensions.length === 0, "ambient-extension-or-mcp-active");
  requireInvariant(settingValue(session.settings, "providers.openaiWebsockets") === "off", "created-websocket-policy-mismatch");
  requireInvariant(settingValue(session.settings, "skillful") === false, "created-skill-listing-policy-mismatch");
  requireInvariant(settingValue(session.settings, "retry.enabled") === false && settingValue(session.settings, "retry.maxRetries") === 0 && settingValue(session.settings, "dev.autoqa") === false, "created-config-mismatch");
  const createdFallbackChains = settingValue(session.settings, "retry.fallbackChains");
  requireInvariant(createdFallbackChains && typeof createdFallbackChains === "object" && Object.keys(createdFallbackChains).length === 0, "created-fallback-chains-mismatch");
  const selectedSkills = session.skills;
  requireInvariant(selectedSkills.length === 27 && sameNames(selectedSkills.map(skill => skill.name), expectedSkills), "resolved-pocock-catalog-mismatch");
  for (const skill of selectedSkills) {
    const skillPath = await realpath(skill.filePath);
    requireInvariant(customDirectories.some(root => skillPath.startsWith(`${root}${sep}`)), "resolved-skill-outside-original-directories");
    // Confronto reale dei file skill risolti con la revisione originale; no copie.
    const { stdout: pinnedContent } = await run("git", ["-C", upstream, "show", `${pin}:${relative(upstream, skillPath)}`], { maxBuffer: 4 * 1024 * 1024 });
    requireInvariant(pinnedContent === await readFile(skillPath, "utf8"), "resolved-skill-differs-from-original-pin");
  }
  modelBefore = { provider: session.model.provider, id: session.model.id, thinking: session.thinkingLevel };
  if (trial) {
    stage = "native-read-only-pocock-trial";
    requireInvariant(remainingLaunchMs() > 0 && !failure && budget, "launch-deadline-exhausted");
    requireInvariant(!session.isStreaming, "bound-session-already-streaming");
    unsubscribe = session.subscribe(event => {
      if (event.type === "agent_end") {
        nativeLifecycle.end = { isTerminal: event.isTerminal, yielded: event.yielded, awaitingAsyncWork: event.awaitingAsyncWork };
      }
      if (event.type === "tool_execution_start" && event.toolName === "read") {
        const args: unknown = event.args;
        const path = args && typeof args === "object" && "path" in args && typeof args.path === "string" ? args.path : "";
        const category = path === "skill://ask-matt" || path.startsWith("skill://ask-matt:") || path.startsWith("skill://ask-matt/") || path.startsWith(join(upstream, "skills/engineering/ask-matt/SKILL.md"))
          ? "askMatt"
          : path.startsWith("/home/iingenito/projects/personal/.worktrees/agent-os-pocock-reconcile/tasks/plan.md")
            ? "currentPlan"
            : path.startsWith(join(cwd, "tasks/plan.md")) || path.startsWith("tasks/plan.md") ? "boundPlan" : "other";
        pendingReads.set(event.toolCallId, category);
      }
      if (event.type === "tool_execution_end") {
        const category = pendingReads.get(event.toolCallId);
        if (category && !event.isError) successfulReads[category]++;
        pendingReads.delete(event.toolCallId);
      }
    });
    promptStarted = true;
    await session.prompt(`Stessa missione Agent OS #35/#52 (${missionId}), stesso provider bound ${sessionId}, CWD ${cwd}. Il coordinatore OMP/Pocock corrente è 01a139d2-93a6-704a-a1cc-570907f479a9, NON questa sessione: tu resti observer/observe. Questo è un solo trial reale read-only del provider e della lettura del metodo entro 15 minuti dal lancio/30 dispatch HTTP modello, tentativi HTTP nativi inclusi. Nessun retry manuale, fallback, specialista, servizio, browser, mutazione di progetto, rilascio MVP o trasferimento di ownership.
Usa soltanto read. Leggi esplicitamente l'originale skill://ask-matt dal catalogo pin ${pin}; segui le sue indicazioni pertinenti solo come lettura, senza pretendere o dichiarare l'esecuzione completa del metodo quando richiede scritture, TDD o delega. Leggi la RFC corrente integrale e il Plan Active in /home/iingenito/projects/personal/.worktrees/agent-os-pocock-reconcile/rfcs/RFC-0001-principles.md e /home/iingenito/projects/personal/.worktrees/agent-os-pocock-reconcile/tasks/plan.md, e confronta tasks/plan.md nel CWD bound. Leggi le SPEC Active mobile-control, mcp-access e il contratto provider team-execution pertinenti. Catalogo e pin non sono prova di applicazione del metodo.
Riferisci concisamente identity, coordinatore/provider/ruolo, fase, scope e decisioni correnti citando fonti e righe. Distingui fatti, deduzioni e informazioni mancanti; indica SÌ/NO/NON APPLICABILE e l'azione necessaria per ogni NO. Evidenzia drift tra fonti senza correggerlo. Scegli il percorso Pocock pertinente e spiega quali passi non sono applicabili nel trial read-only. Niente segreti, credenziali o transcript storico nella risposta. Il solo SDK stream o questo esito non concede GO missione, autonomìa esecutiva o rilascio.`);
    requireInvariant(!failure && remainingLaunchMs() > 0, "launch-deadline-exhausted");
    httpSummary = budget.snapshot();
    requireInvariant(!session.isStreaming && httpSummary.admitted > 0, "native-trial-not-settled-or-no-http-dispatch");
    requireInvariant(httpSummary.blocked === 0 && httpSummary.reason === null, "native-trial-http-budget-stopped");
    requireInvariant(nativeLifecycle.end?.isTerminal === true && nativeLifecycle.end.awaitingAsyncWork !== true, "native-trial-terminal-boundary-unconfirmed");
    const terminal = session.getLastAssistantMessage();
    terminalStopReason = terminal?.stopReason;
    requireInvariant(terminal?.stopReason === "stop", "native-trial-terminal-not-successful");
    const answer = session.getLastAssistantText();
    requireInvariant(answer, "native-trial-final-answer-unavailable");
    // Necessaria alla review indipendente del metodo: non va in stdout.
    finalResponseDirectory = await mkdtemp(join(tmpdir(), "mission35-native-pocock-review-"));
    await chmod(finalResponseDirectory, 0o700);
    const responsePath = join(finalResponseDirectory, "final-response.txt");
    await writeFile(responsePath, answer, { encoding: "utf8", mode: 0o600, flag: "wx" });
    finalResponseFile = responsePath;
    requireInvariant(successfulReads.askMatt > 0 && successfulReads.currentPlan > 0 && successfulReads.boundPlan > 0, "native-trial-required-read-not-observed");
    requireInvariant(JSON.stringify(readMissionAuthority(cwd, sessionId)) === JSON.stringify(authority), "post-trial-authority-changed");
  }
  modelAfter = { provider: session.model?.provider, id: session.model?.id, thinking: session.thinkingLevel };
  requireInvariant(JSON.stringify(modelAfter) === JSON.stringify(modelBefore), "post-trial-model-thinking-changed");
  const entriesAfter = manager.getEntries();
  nativeEntryCountAfter = entriesAfter.length;
  const newMessages = entriesAfter.slice(entriesBefore.length).filter(entry => entry.type === "message");
  requireInvariant(trial || newMessages.length === 0, "unexpected-native-message-entry");
  if (trial) {
    requireInvariant(newMessages.filter(entry => entry.message.role === "user").length === 1
      && newMessages.some(entry => entry.message.role === "assistant")
      && newMessages.every(entry => ["user", "assistant", "toolResult"].includes(entry.message.role)), "native-trial-message-scope-mismatch");
  }
  requireInvariant((trial || modelDispatches === 0) && !session.isStreaming, "unexpected-model-activity");
  observed = {
    sessionId: session.sessionId, cwd: manager.getCwd(), model: `${session.model.provider}/${session.model.id}`, thinking: session.thinkingLevel,
    pocockOriginalPin: upstreamHead.trim(), resolvedSkillCount: selectedSkills.length, resolvedSkillNames: selectedSkills.map(skill => skill.name).sort(),
    existingStoredNativeAuth: authSource?.kind === "oauth" || authSource?.kind === "api_key",
    retryEnabled: settingValue(session.settings, "retry.enabled"), maxRetries: settingValue(session.settings, "retry.maxRetries"),
    fallbackChains: createdFallbackChains, autoqa: settingValue(session.settings, "dev.autoqa"),
    activeTools: session.getActiveToolNames(), privateOpenaiWebsockets: settingValue(session.settings, "providers.openaiWebsockets"),
    documentaryAuthority: authority,
    privateSkillful: settingValue(session.settings, "skillful"),
  };
  stage = "dispose";
} catch (error) {
  failure ??= error instanceof Incompatibility ? error.message : "native-preflight-error-redacted";
} finally {
  if (session) {
    modelAfter = { provider: session.model?.provider, id: session.model?.id, thinking: session.thinkingLevel };
    if (modelBefore && JSON.stringify(modelAfter) !== JSON.stringify(modelBefore)) failure ??= "post-trial-model-thinking-changed";
  }
  // close() è l'API pubblica manager, non un getter/dispose immaginario.
  // session.dispose può scrivere metadata e libera le entries: conteggio prima.
  try { if (manager && nativeEntryCountAfter === undefined) nativeEntryCountAfter = manager.getEntries().length; }
  catch { failure ??= "native-entry-count-unavailable"; }
  try {
    if (session) {
      session.beginDispose();
      if (trial) await (abortWork ?? session.abort({ goalReason: "internal", reason: "bounded-native-read-only-trial-cleanup" }));
    }
  } catch { failure ??= "native-trial-abort-failed"; }
  unsubscribe?.();
  try { if (session) await session.dispose(); }
  catch { failure ??= "native-session-disposal-failed"; }
  try { if (manager) await manager.close(); }
  catch { failure ??= "native-manager-close-failed"; }
  try { authStorage?.close(); }
  catch { failure ??= "native-auth-close-failed"; }
  settings?.cancelPendingSaves();
  authSettings?.cancelPendingSaves();
  try {
    after = await diskSnapshot(before?.messageEntryCount);
    if (before && !promptStarted && after.messageEntryCount !== before.messageEntryCount) failure ??= "persisted-message-count-changed";
    if (before && after.originalMessagePrefixSha256 !== before.originalMessagePrefixSha256) failure ??= "persisted-original-messages-changed";
    if (before && (after.bindingEntryCount !== before.bindingEntryCount || after.bindingSha256 !== before.bindingSha256)) failure ??= "persisted-binding-changed";
    if (before && promptStarted && (after.messageRoles.user - before.messageRoles.user !== 1
      || after.messageRoles.other !== before.messageRoles.other
      || after.messageRoles.assistant < before.messageRoles.assistant
      || after.messageRoles.toolResult < before.messageRoles.toolResult)) failure ??= "persisted-trial-message-scope-mismatch";
  } catch { failure ??= "post-disposal-session-snapshot-unavailable"; }
  httpSummary = budget?.snapshot();
  budget?.close();
  globalThis.fetch = originalFetch;
  clearTimeout(launchTimer);
  if (trial) process.removeListener("SIGTERM", stopTrial);
  for (const name of consoleNames) console[name] = originalConsole[name];
}
// Allowlist unica: non emette transcript, prompt, API keys, token, account,
// errori native, eventi child o config integrale. Hash diversi sono metadata
// osservati, NON una promessa di byte-identità e NON un ownership transfer.
process.stdout.write(`${JSON.stringify({
  status: failure ? "incompatible" : trial ? "trial-read-only-complete-review-required" : "metadata-ready", stage, failure,
  observed, before, after, nativeEntryCountBefore, nativeEntryCountAfter,
  transcriptBytesChanged: before && after ? before.sha256 !== after.sha256 : undefined,
  modelDispatches, suppressedConsoleCalls,
  mode: trial ? "trial" : "metadata-only", promptStarted,
  modelBefore, modelAfter, httpBudget: httpSummary, successfulReads, terminalStopReason,
  nativeEnd: nativeLifecycle.end,
  finalResponseFile, finalResponseReview: finalResponseFile ? "private-0600; parent-review-and-cleanup-required" : "not-saved",
  finalResponseDirectory, tempLifecycle: finalResponseDirectory ? "parent-removes-directory-after-private-review-even-on-error" : "not-created",
  launchElapsedMs: Math.round(process.uptime() * 1000), sdkLaunchDeadlineMs: trial ? launchDeadlineMs : undefined,
  sdkLaunchDeadlineAt: trial ? launchDeadlineAt : undefined,
  externalLaunchDeadline: trial ? "parent-must-install-OS-timeout-900s-before-launch" : "not-applicable",
  sourceRole, ownershipTransferred: false,
  pendingCommandContinuity: "unknown", pocockTrialApplied: trial && !failure ? "native-reads-observed; independent-method-review-required" : "not-established",
  modelDispatchAccounting: trial ? "global-native-HTTP-POST-enforcement; model-retries-and-secondary-dispatches-included; exact-native-OAuth-refresh-excluded" : "main-first-dispatch-only; not a total HTTP request counter",
  limits: ["native-DNS-TLS-preconnect-possible", "native-session-model-thinking-metadata-writes-possible", "native-private-cache-and-existing-auth-session-affinity-metadata-writes-possible", trial ? "read-only-provider-method-qualification-not-autonomous-execution-or-release" : "no-browser-device-or-trial-evidence", "no-browser-tablet-ChatGPT-or-release-evidence", "OS-timeout-installation-and-temp-file-cleanup-owned-by-parent"],
})}\n`);
if (failure) process.exitCode = 1;
