// Disposable test preload: install before native modules capture global fetch.
const nativeFetch = globalThis.fetch;
function requireLoopback(input) {
  const url = new URL(typeof input === 'string' || input instanceof URL ? String(input) : input.url);
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || url.username || url.password) {
    throw new Error('Non-loopback transport denied by private qualification fixture');
  }
}
const guarded = async (input, init) => {
  requireLoopback(input);
  return nativeFetch(input, { ...init, redirect: 'error' });
};
if (typeof nativeFetch.preconnect === 'function') guarded.preconnect = (url, options) => {
  requireLoopback(url);
  return nativeFetch.preconnect(url, options);
};
globalThis.fetch = guarded;
