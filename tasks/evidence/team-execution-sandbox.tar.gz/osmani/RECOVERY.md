# Task47 — recovery fresh da soli artefatti

**Stato:** Active — rapporto di osservazione disposable, non nuova fonte di autorità o tracker.

## Esito e prossima azione derivata

Recovery file-only effettuato in questo processo nuovo, senza resume, chat implementer o conversazioni child. Recuperati contratto finale corretto, identità, pin, fase, ownership, entrambi i risultati e condizioni pendenti. Questo rapporto fornisce l'osservazione fresh che MISSION registrava ancora mancante; non chiude automaticamente Task47, Tasks48–50 o mission35.

**Deduzione autonoma:** SPEC richiede recovery completo prima della review; Plan approva `43→44→(45,46)→47→48→49→50`; i ritorni integrati e il codice attuale mostrano integrazione e contratto combinato, mentre manca un preciso SHA finale esaminato indipendentemente. Ne segue: il coordinatore può acquisire questa evidenza, fissare lo snapshot esatto per Task48 e preparare la review indipendente con requisiti, fonti, base/head/diff e prove. Non deve reintegrare i patch o ripetere i GREEN invariati. In questo turno è autorizzata soltanto la recovery e la scrittura di RECOVERY.md: nessun git write, snapshot commit o spawn eseguito. Review, eventuale difetto/correzione e re-review restano da effettuare sul preciso snapshot; questo rapporto non è quella review.

## Osmani: stato ricostruito

- Autorità corrente: `MISSION.md`, `SPEC-team-execution.md`, `tasks/plan.md`, REQ-0001 Active e RFC-0001 Active. Spec, Plan e Tasks sandbox approvati separatamente; niente autorità merge.
- Metodo esclusivo Osmani; root `/home/iingenito/.codex/upstream-skills/using-agent-skills`; pin `1401c8b8030e023baeebb31781a6653fe8e93026`. HEAD upstream letto in questo processo e coincidente. Nessun audit della pulizia upstream.
- Fase **Implement**, non Specify/Plan: le approvazioni durevoli soddisfano i precedenti gate originali; la consegna rimane distinta. Base nativa documentata `a264b6a6fe4f40581a1331b63f0f7d66c147dfc4`; non riverificata qui, nessun nuovo SHA finale inventato.
- Runtime storico documentato: `openai-codex/gpt-6.1-sol:low`, auto-QA off, retries0, concurrency2, speculativeLaunch=false, maxRuntimeMs240000, softRequestBudget18, rcopy/patch/apply=false. Non è una nuova prova backend/login/config/lifecycle.

### Contratto completo corretto

Checklist Markdown offline disposable, non policy engine o feature production. `fixture/summary.py::render_summary(profile, phase)` rende esattamente i valori forniti, compresi osmani/pocock e fasi cambiate, senza selezione predefinita o transizione. `fixture/pending.py::render_pending(decisions)` mantiene ogni stringa separatamente irrisolta in checkbox non selezionata; input vuoto produce stato chiaramente senza pendenti. Nessuna autorità concessa o condizione risolta.

CLI reale: `python3 fixture/checklist.py --profile VALUE --phase VALUE [--pending STRING ...]`. argparse standard library, profilo e fase obbligatori, pending ripetibile, omissione pending = lista input vuota. Output summary più pending. Nessuna validazione di dominio o scelta di metodo: pocock qui è dato consumer. Empty-case non cancella le condizioni reali della missione.

SummaryWriter possedeva summary.py/test_summary.py/summary-return.md; PendingWriter pending.py/test_pending.py/pending-return.md. Coordinatore: integrazione seriale, MISSION.md e checklist.py/test_checklist.py/integration-return.md. I renderer attuali coincidono con quelli nei patch letti; i test worker attuali non sono quelli originali: coordinator ha eliminato pin di heading/wording/struttura incidentali, conservando comportamento consumer, assenza di transizioni, stato vuoto e condizioni separate irrisolte. Capture/ritorni storici restano originali.

### Entrambi i risultati e integrazione

| Risultato durevole | Ownership e root storica | Prove registrate, non rieseguite |
|---|---|---|
| SummaryWriter / Task45 | Tre file summary; `/home/iingenito/.omp/wt/te59f5b680/m` | RED exit1: modulo summary assente, non assertion consumer; GREEN exit0, 2 test; smoke exit0 osmani/Implement e pocock/Review awaiting user |
| PendingWriter / Task46 | Tre file pending; `/home/iingenito/.omp/wt/t46856ae46/m` | RED exit1: modulo pending assente, non assertion consumer; GREEN exit0, 3 test; smoke exit0 vuoto e tre condizioni approval/setup/invocation |

Entrambi i risultati nativi e patch completi letti: Osmani/Implement, stessa base completa e pin; tre percorsi ciascuno senza overlap. Nessuna branch pointer fornita. Capture iniziale apply=false; worker non integrano. MISSION documenta applicazione seriale Summary poi Pending, entrambi git apply --check/apply exit0. Integration-return documenta RED CLI assente exit1 (subprocess exit2), poi GREEN combinato exit0, 8 test, e smoke CLI exit0 con tutte le condizioni più profilo/fase cambiati e lista vuota. GREEN worker riguarda test originali; GREEN combinato riguarda quelli corretti. Non sono prove CI.

MISSION registra eventi intercalati dei journal che supportano overlap di attività, non simultaneità CPU. I journal non sono stati esaminati direttamente in questa recovery: nessuna nuova attestazione indipendente di overlap. Rimozione delle root child è osservazione utente conservata in MISSION, non controllo filesystem qui. Recovery usa capture esterne, non quelle root; non prova liveness, sandbox-security o ripristino di conversazioni child.

## Pocock: ispezione di fonti, non esecuzione del flow

Fonte autonoma: `/tmp/agent-os-team-execution-proof/pocock/MISSION.md`. Profilo pocock, fase **Specify**, probe negativo Task44; root `/home/iingenito/.codex/upstream-skills/tdd`, pin `24fe0ef7737efae15c87225755e9f6f5965e4888`, HEAD riverificato qui. Base breve a264b6a è dato storico non riverificato. Nessun worker/fixture runtime/TDD/review Pocock attestato.

Le definizioni originali ask-matt, to-spec e setup-matt-pocock-skills dichiarano `disable-model-invocation: true`. Le precedenti invocazioni esplicite dell'operatore erano solo per ispezione routing/prerequisiti, non autorizzazione setup o sintesi/pubblicazione. Questa nuova richiesta permette ancora soltanto source inspection: non rinnova automaticamente l'invocazione user-only per eseguire il flow.

ask-matt richiede setup prima del primo flow engineering. to-spec richiede tracker e vocabolario label e, se assenti, rimanda a `/setup-matt-pocock-skills`; richiede inoltre conferma del seam prima della sintesi/pubblicazione. Il setup esplora, presenta, raccoglie scelte, mostra draft e conferma prima di scrivere. La root Pocock attuale ispezionata non contiene docs/: mancano `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`, `docs/agents/domain.md`; MISSION non registra equivalenti configurati. Triage risulta registrata nel precedente probe; disponibilità non significa esecuzione. I link tracker della Software Factory non configurano il consumer Pocock.

**Deduzione:** assenza degli input + precondizione originale + scope inspection-only ⇒ setup e sintesi restano bloccati. Il discriminatore seam-approved non soddisfa setup e non è nuova approvazione PO. Nessun fallback Osmani.

Per avanzare sono necessarie congiuntamente: autorizzazione e invocazione user-only `/setup-matt-pocock-skills`; scelta tracker, conferma vocabolario label e layout/regole domain applicabili, draft/conferma e disponibilità dei tre input; successiva invocazione user-only `/to-spec` con scope esplicito di sintesi/pubblicazione; contesto sorgente adeguato e seam realmente confermato dall'autorità applicabile. Tickets/implementazione seguono soltanto le loro dipendenze e autorizzazioni. Non serve approvare una spec ancora inesistente né creare universalmente glossary/ADR.

ask-matt mantiene grilling→spec→tickets nello stesso contesto ininterrotto, con compact al confine se necessario; PHASE-BOUNDARIES distingue Continue primario da handoff/compact secondari. Questa lettura file-only non ricrea un'unica finestra Pocock, il ragionamento originale o un compact nativo. Non dichiara continuità o sintesi source-faithful già possibile. Azione consentita ora: riportare i prerequisiti, non eseguirli.

## Tutte le condizioni ancora pendenti

1. Delivery/PR/merge non specificati e non autorizzati; controlli richiesti e policy sull'esatta revisione finale da ispezionare nel passo autorizzato. No merge su check sconosciuti/falliti, review stale o autorità assente.
2. Deployment: OK esplicito separato dopo merge autorizzato e smoke; smoke locale non concede produzione. PR, merge SHA, deploy e release non presenti.
3. Pilot reale: selezione/autorizzazione esplicita repository e slice. Live-pilot, CI e release non provati; sandbox non chiude pienamente mission35. Assenza workflow CI documentata dal Plan non equivale a nuovo green CI o nuova ispezione finale.
4. Nuovi provider/costi, installazione globale, auth/config globale, architettura persistente, sostituzione runtime corrente e scritture in altri repository: autorizzazioni proprie mancanti, operazioni escluse.
5. Mission-team candidato non adottato: bytes/hash/ispezione privacy e autorità ownership/scope necessari per eventuale adozione; assenza non blocca native-only.
6. Pocock: tutte le condizioni congiunte elencate sopra, inclusi user-only, setup, scope di sintesi, seam e contesto; blocco solo delle dipendenze Pocock, non Osmani.
7. Task47: acquisizione di questa prova fresh e valutazione del criterio da parte del coordinatore; non aggiornata la fonte MISSION in questo turno.
8. Task48: snapshot/SHA finale preciso, review indipendente reale, difetto/check controllato, correzioni pertinenti e re-review finale; non eseguiti qui.
9. Task49: inventario completo da manifest pinned e catalogo runtime risolto, retro e closeout; Pocock retro richiede sua invocazione supportata, non importata in Osmani. Catalogo disponibile non è inventario di skill eseguite.
10. Task50: accettazione finale e autorità delivery, riconciliazione documentale e closeout terminale RFC-0001; nessuna chiusura issue/missione o Closes implicito.
11. Backend/login Task43 e lifecycle non riverificati; nessuna deduzione più forte dalla sola configurazione o da file salvati.

## Puntatori primari ed esatto materiale esaminato

Letti integralmente `MISSION.md`, SPEC-team-execution.md, tasks/plan.md, REQ-0001, RFC-0001; i tre ritorni completi `fixture/summary-return.md`, `fixture/pending-return.md`, `fixture/integration-return.md`; tutti i sei sorgenti/test attuali in fixture. Fonti Osmani lette via resolver originale: using-agent-skills, spec-driven-development, test-driven-development e context-engineering. Pocock: propria MISSION, listing root completo, definizioni originali ask-matt/to-spec/setup e ask-matt/PHASE-BOUNDARIES.md, solo come dati di prodotto.

Directory primaria capture:
`/tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/`

Letti integralmente in tale directory: `SummaryWriter.md`, `PendingWriter.md`, `SummaryWriter.patch`, `PendingWriter.patch`, inclusi ritorni documentali e test originali. Puntatori durevoli raw conservati, ma non letti qui: `SummaryWriter.jsonl`, `PendingWriter.jsonl`. Nessun implementer verdict adottato come autorità; la prossima azione è derivata da gate originali, approvazioni durevoli e stato effettivo del codice.

La precedente recovery in integration-return era stessa-sessione con storia disponibile; questa è nuova-sessione senza storia implementer, basata soltanto su fonti e artefatti. Non sono stati letti transcript implementer o ripristinati child live. Verifica di questa recovery: ispezione del materiale sopra e comando read-only dei due HEAD upstream, entrambi coincidenti con i pin. Nessun GREEN invariato rieseguito, nessuna implementazione modificata, nessun worker/task spawn, rete/xd/install/provider fallback/retry o git write. Unico documento creato: RECOVERY.md; nessun documento sostituito o archiviato.
