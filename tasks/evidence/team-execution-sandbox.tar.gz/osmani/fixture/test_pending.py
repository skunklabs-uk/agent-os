import unittest

from pending import render_pending


class PendingTests(unittest.TestCase):
    def test_empty_list_reports_no_pending_decisions(self):
        markdown = render_pending([])
        self.assertRegex(markdown.lower(), r"(?:no|without)\s+pending\s+decisions|nessuna\s+decisione\s+pendente")
        self.assertNotIn("[ ]", markdown)

    def test_single_approval_remains_unresolved(self):
        decision = "Deployment requires separate explicit approval after smoke."
        markdown = render_pending([decision])
        matching = [line for line in markdown.splitlines() if decision in line]
        self.assertEqual(len(matching), 1)
        self.assertIn("[ ]", matching[0])
        self.assertNotIn("[x]", markdown.lower())

    def test_multiple_approval_setup_and_invocation_decisions_remain_separate(self):
        decisions = [
            "Delivery/PR/merge authorization remains absent.",
            "Pocock original setup remains required for its separate mission.",
            "Pocock user-only invocation remains required; not an Osmani prerequisite.",
        ]
        markdown = render_pending(decisions)
        for decision in decisions:
            matching = [line for line in markdown.splitlines() if decision in line]
            self.assertEqual(len(matching), 1, decision)
            self.assertIn("[ ]", matching[0])
        self.assertNotIn("[x]", markdown.lower())


if __name__ == "__main__":
    unittest.main()
