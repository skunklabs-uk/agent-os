import argparse

from pending import render_pending
from summary import render_summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--pending", action="append", default=[])
    args = parser.parse_args()
    print(render_summary(args.profile, args.phase), end="\n")
    print(render_pending(args.pending), end="")
