def render_summary(profile, phase):
    return f"## Summary\n\n- Profile: {profile}\n- Phase: {phase}\n"
