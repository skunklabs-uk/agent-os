import os
from pathlib import Path
import subprocess
import sys
import unittest


CLI = Path(__file__).with_name("checklist.py")


class ChecklistTests(unittest.TestCase):
    def run_cli(self, profile, phase, decisions=()):
        command = [sys.executable, str(CLI), "--profile", profile, "--phase", phase]
        for decision in decisions:
            command.extend(["--pending", decision])
        result = subprocess.run(
            command, capture_output=True, text=True,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_supplied_profiles_and_changed_phases_reach_consumer(self):
        for profile, other in (("osmani", "pocock"), ("pocock", "osmani")):
            for phase in ("Implement", "Review awaiting user"):
                with self.subTest(profile=profile, phase=phase):
                    output = self.run_cli(profile, phase)
                    self.assertIn(profile, output)
                    self.assertNotIn(other, output)
                    self.assertIn(phase, output)
                    if phase != "Implement":
                        self.assertNotIn("Implement", output)

    def test_every_pending_condition_remains_separately_unresolved(self):
        decisions = [
            "Delivery/PR/merge authorization remains absent.",
            "Deployment requires separate explicit OK after smoke.",
            "Real pilot requires approved repository and slice; live/CI/release unproven.",
            "New provider/cost/global install/auth/config/architecture requires approval.",
            "Mission-team adoption requires bytes/hash/privacy and ownership/scope approval.",
            "Pocock setup remains required even after seam approval.",
            "Pocock user-only invocation remains required; not an Osmani prerequisite.",
        ]
        output = self.run_cli("osmani", "Implement", decisions)
        for decision in decisions:
            matching = [line for line in output.splitlines() if decision in line]
            self.assertEqual(len(matching), 1, decision)
            self.assertIn("[ ]", matching[0])
        self.assertNotIn("[x]", output.lower())

    def test_no_pending_arguments_report_clear_empty_state(self):
        output = self.run_cli("pocock", "Plan")
        self.assertRegex(output.lower(), r"(?:no|without)\s+pending\s+decisions|nessuna\s+decisione\s+pendente")
        self.assertNotIn("[ ]", output)


if __name__ == "__main__":
    unittest.main()
