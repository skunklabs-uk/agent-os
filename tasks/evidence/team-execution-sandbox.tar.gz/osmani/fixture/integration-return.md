# Task47 — integrazione e recovery same-session

**Stato:** Active — evidenza sandbox; fresh artifact-only recovery separato ancora da eseguire.
**Metodo:** esclusivamente Osmani; fase Implement; root originale `/home/iingenito/.codex/upstream-skills/using-agent-skills`, pin `1401c8b8030e023baeebb31781a6653fe8e93026`.
**Base:** `a264b6a6fe4f40581a1331b63f0f7d66c147dfc4`; nessun nuovo commit/SHA finale in questo passo.

## Recovery effettivo e autorità

Ripresa della stessa sessione coordinator con storia disponibile, non contesto pulito. Riletto MISSION.md e integralmente entrambi i patch con ritorni completi; non solo sintesi. Fonti autorevoli già lette nella sessione: SPEC-team-execution.md, tasks/plan.md, REQ-0001 e RFC-0001; router e TDD originali selezionati, aggiunte skill Osmani incremental-implementation e git-workflow-and-versioning per l'azione pertinente. Recuperati profilo, pin, fase, base, entrambi i risultati, ownership e tutte le decisioni pendenti.

Richiesta considerata: merge/deploy ora. Decisione **NO-GO**: autorizzazione merge/PR/delivery non specificata ed esclusa; deployment richiede OK esplicito separato dopo smoke. Azione concreta: nessun comando merge/deploy/GitHub o CI artificiale; proseguita invece l'integrazione sandbox indipendentemente autorizzata. Discriminatore Pocock: seam approvato non soddisfa setup originale o invocazione user-only, che restano bloccanti per quella missione; non bloccano Osmani.

L'utente riferisce root native dei figli ora rimosse e patch/journal ancora presenti: lifecycle osservato comunicato, non certificazione di sandbox security, isolamento ostile o liveness dopo interruzione. I vecchi percorsi child nei ritorni sono storici, non destinazioni correnti di recovery.

## Puntatori durevoli completi

Directory capture:
`/tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/`

- SummaryWriter: `SummaryWriter.md` risultato completo, `SummaryWriter.jsonl` journal, `SummaryWriter.patch` codice/test/ritorno completo; ritorno ora integrato `fixture/summary-return.md`.
- PendingWriter: `PendingWriter.md` risultato completo, `PendingWriter.jsonl` journal, `PendingWriter.patch` codice/test/ritorno completo; ritorno ora integrato `fixture/pending-return.md`.
- Entrambi: Osmani/Implement, pin/base sopra, tre file di proprietà distinti. RED per modulo realmente assente; GREEN Summary 2 test, Pending 3 test; smoke diretti exit 0. MISSION conserva eventi reali di overlap intercalato, non simultaneità CPU.
- Capture native precedenti `apply=false`, non applicate automaticamente; nessuna branch pointer fornita. Ora applicazione esplicita seriale coordinator.

## Integrazione seriale osservata

Comandi effettivi nella root parent `/tmp/agent-os-team-execution-proof/osmani`, prima Summary poi Pending, entrambe le chiamate exit 0 senza output:

```bash
git apply --check /tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/SummaryWriter.patch && git apply /tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/SummaryWriter.patch
git apply --check /tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/PendingWriter.patch && git apply /tmp/agent-os-team-execution-proof/sessions-osmani-workers/2026-10-10T20-37-33-057Z_01a12789-0301-7405-a462-876e4a90d7fc/PendingWriter.patch
```

Nessun nuovo worker o applicazione automatica. Sei file worker integrati. Correzione coordinator ai test importati: rimosse asserzioni su heading, wording esatto e intera struttura Markdown incidentale; mantenuti profilo/fase ricevuti, assenza di selezione/transizione inventata, decisioni separate e irrisolte e stato vuoto semanticamente chiaro. Capture originali e ritorni storici non riscritti; GREEN worker precedente riguarda i test precedenti, GREEN combinato sotto quelli corretti.

## Contratto finale completo

Fixture offline disposable, non policy engine o feature production:

- `render_summary(profile, phase)` in `fixture/summary.py`: Markdown dei valori ricevuti, osmani/pocock e fasi cambiate; nessun default o transizione.
- `render_pending(decisions)` in `fixture/pending.py`: ogni stringa separatamente visibile e irrisolta; lista vuota chiaramente senza pendenti; nessuna concessione autorità.
- CLI reale `python3 fixture/checklist.py --profile VALUE --phase VALUE [--pending STRING ...]`: argparse stdlib, profilo/fase esplicitamente forniti, pending ripetibile; stampa summary più pending. Nessuna validazione di dominio, selezione metodologica, transizione o policy aggiunta. Assenza di `--pending` rappresenta la lista vuota, non la risoluzione delle decisioni reali della missione.
- `fixture/test_checklist.py`: subprocess reale, entrambi i profili e fasi cambiate, tutte le condizioni approval/setup/invocation/pilot separatamente visibili, empty case. Non pin di heading/wording esatto.
- Ownership coordinator aggiunta: checklist.py, test_checklist.py, integration-return.md e MISSION.md; renderer worker invariati, correzioni dei test esplicite sopra.

## RED reale

Completato tutto `fixture/test_checklist.py` prima di creare CLI. Comando:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s fixture -p test_checklist.py -v
```

Exit **1**, `Ran 3 tests in 0.098s`, `FAILED (failures=6)`. Ogni subprocess exit 2 con errore reale:

```text
/usr/bin/python3: can't open file '/tmp/agent-os-team-execution-proof/osmani/fixture/checklist.py': [Errno 2] No such file or directory
```

Solo dopo RED implementato CLI minimo: argparse più due renderer già integrati.

## GREEN combinato, una sola esecuzione

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s fixture -p 'test_*.py' -v
```

Exit **0**, `Ran 8 tests in 0.166s`, `OK`: 3 ChecklistTests, 3 PendingTests, 2 SummaryTests. Nessun test saltato, nessuna riesecuzione invariata. Nessuna CI dichiarata.

## Smoke CLI effettivo

```bash
PYTHONDONTWRITEBYTECODE=1 python3 fixture/checklist.py --profile osmani --phase Implement --pending 'Delivery/PR/merge authorization remains absent.' --pending 'Deployment requires separate explicit OK after smoke.' --pending 'Real pilot requires approved repository and slice; live/CI/release unproven.' --pending 'New provider/cost/global install/auth/config/architecture requires approval.' --pending 'Mission-team adoption requires bytes/hash/privacy and ownership/scope approval.' --pending 'Pocock setup remains required even after seam approval.' --pending 'Pocock user-only invocation remains required; not an Osmani prerequisite.' && PYTHONDONTWRITEBYTECODE=1 python3 fixture/checklist.py --profile pocock --phase 'Review awaiting user'
```

Exit **0**, output reale:

```markdown
## Summary

- Profile: osmani
- Phase: Implement

## Pending decisions

- [ ] Delivery/PR/merge authorization remains absent.
- [ ] Deployment requires separate explicit OK after smoke.
- [ ] Real pilot requires approved repository and slice; live/CI/release unproven.
- [ ] New provider/cost/global install/auth/config/architecture requires approval.
- [ ] Mission-team adoption requires bytes/hash/privacy and ownership/scope approval.
- [ ] Pocock setup remains required even after seam approval.
- [ ] Pocock user-only invocation remains required; not an Osmani prerequisite.
## Summary

- Profile: pocock
- Phase: Review awaiting user

## Pending decisions

No pending decisions.
```

## Pendenti e prossimo passo

Fonte corrente delle decisioni: sezione pendenti di MISSION.md. Nessuna decisione risolta dall'output empty-case. Restano assenti autorità delivery/PR/merge e OK deployment; scelta/autorizzazione repository/slice pilot reale e prove live/CI/release; autorizzazioni provider/costi/global install/auth/config/architettura; bytes/hash/privacy e ownership/scope del candidato mission-team, non adottato; invocazione user-only e setup originale Pocock anche dopo seam approval. Nessun global/auth/other-repository write, rete/xd, nuovo provider, retry o espansione modello.

Prossima operazione coordinator: fissare snapshot esatto del codice per Task48 secondo istruzione successiva; qui nessun commit/PR/merge/deploy. Fresh artifact-only recovery va eseguito separatamente senza ereditare questa chat e rimane evidenza Task47 mancante. Task48 richiede review indipendente del preciso snapshot/SHA e correzione/re-review; Task49 inventario/retro/closeout, Task50 accettazione/autorità finale. Non dichiarata chiusura completa Task47 o mission35 finché manca fresh recovery. Nessun documento archiviato, missione Active.
