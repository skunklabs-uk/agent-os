import unittest

from summary import render_summary


class SummaryTests(unittest.TestCase):
    def test_supplied_profiles_are_visible_without_default_selection(self):
        for profile, other in (("osmani", "pocock"), ("pocock", "osmani")):
            with self.subTest(profile=profile):
                markdown = render_summary(profile, "Implement")
                self.assertIn(profile, markdown)
                self.assertNotIn(other, markdown)

    def test_supplied_changed_phases_are_preserved_without_transition(self):
        phases = ("Specify", "Plan", "Implement", "Review awaiting user")
        for profile in ("osmani", "pocock"):
            for phase in phases:
                with self.subTest(profile=profile, phase=phase):
                    markdown = render_summary(profile, phase)
                    self.assertIn(profile, markdown)
                    self.assertIn(phase, markdown)
                    for other in phases:
                        if other != phase:
                            self.assertNotIn(other, markdown)


if __name__ == "__main__":
    unittest.main()
