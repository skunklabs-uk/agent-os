def render_pending(decisions):
    """Render supplied unresolved decisions without granting any authority."""
    if not decisions:
        return "## Pending decisions\n\nNo pending decisions.\n"
    return "## Pending decisions\n\n" + "".join(
        f"- [ ] {decision}\n" for decision in decisions
    )
