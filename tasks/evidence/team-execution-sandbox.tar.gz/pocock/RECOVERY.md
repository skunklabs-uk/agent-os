# Recovery Task47 — Pocock, verifica della correzione

**Stato:** report disposable completato; missione ancora **Active**, fase **Specify**. Fonte corrente: `MISSION.md`; questo report non è un tracker o un permesso di avanzamento.

## Stato e puntatori primari recuperati

Profilo **pocock**, upstream `/home/iingenito/.codex/upstream-skills/tdd`, pin `24fe0ef7737efae15c87225755e9f6f5965e4888`. Base registrata `a264b6a`, non riverificata. Spec, Plan e Tasks43–50 autorizzano il sandbox nei rispettivi limiti, non setup o sintesi/pubblicazione Pocock, merge non specificato, pilot reale o deployment. La richiesta corrente autorizza ispezione delle fonti e aggiornamento di questo solo file.

La correzione è stata letta direttamente in `MISSION.md`, non ricostruita dal precedente verdetto:

- stdout durevole: `/tmp/agent-os-team-execution-proof/pocock-routing.jsonl`;
- sessione canonica: `/tmp/agent-os-team-execution-proof/sessions-pocock-routing/2026-10-10T20-31-41-907Z_01a12783-a753-7184-88fb-3cf45b8ab9ad.jsonl`;
- primo report/finding storico: `/tmp/agent-os-team-execution-proof/pocock-recovery.jsonl`, puntatore registrato in MISSION, contenuto non esaminato qui.

**Esito correzione: SÌ.** Entrambi i puntatori routing sono leggibili e identificano la sessione `01a12783-a753-7184-88fb-3cf45b8ab9ad`. Nella sessione canonica il messaggio utente `25451bdd` autorizza `/skill:ask-matt` e `/skill:to-spec` solo per ispezione, esclude setup/sintesi e qualifica seam-approved come discriminatore. I risultati primari `31955016` e `5ea26600` conservano rispettivamente i realpath originali e il pin; `ac767460` conserva `Unknown skill: spec-driven-development` e il catalogo di 27 skill. Gli stessi tre risultati sono stati estratti anche dallo stdout. Nessun nuovo probe straniero o retry è stato eseguito.

Il precedente RECOVERY affermava che mancavano i percorsi esatti delle prove routing: tale affermazione è superata dalla MISSION corretta e dalla lettura dei due file reali. Questi sono risultati di routing, **non capture di worker Pocock**. Pin e realpath sono verifiche storiche primarie ora recuperate; HEAD corrente, pulizia upstream ed equivalenza byte-per-byte al pin non sono stati riverificati.

## Contratto e risultati effettivamente disponibili

La root completa non contiene `docs/` né `fixture/`. Nessun worker45/46, return, implementazione, test o integration-return Pocock è presente qui; nessun risultato Osmani viene importato. Non sono attestati RED/GREEN, esecuzione della fixture, integrazione o review indipendente del codice.

Il contratto frozen in MISSION è una checklist Markdown offline, non un motore di policy:

- `fixture/summary.py`: `render_summary(profile, phase)` conserva il profilo fornito osmani/pocock e la fase fornita, senza default o transizioni inventate.
- `fixture/pending.py`: `render_pending(decisions)` mantiene separatamente ogni decisione irrisolta; lista vuota significa nessuna pending. Non risolve condizioni e non concede autorità.
- Seam unico: Markdown combinato confrontato con profilo, fase e tutte le decisioni fornite; unittest sul comportamento consumer, non sorgenti/forwarding.
- Ownership prevista: worker45 summary.py/test_summary.py/summary-return.md; worker46 pending.py/test_pending.py/pending-return.md; coordinator integrazione e MISSION. Non prova worker avviati.
- Stack dichiarato Python3.12 standard-library unittest, nessuna installazione; comandi rimandati a Task43, non eseguiti qui. Nuova logica richiederebbe TDD Pocock originale.

Config locale esaminata: 27 includeSkills Pocock, `triage` inclusa; directory engineering/productivity originali; modello `openai-codex/gpt-6.1-sol:low`, auto-QA off, retry 0, fallbackChains vuoto, concurrency 2, backend rcopy, capture patch, apply=false, advisor off. Config non è prova di enforcement o esecuzione; catalogo visibile, configurato e storicamente risolto non equivalgono a skill eseguite.

## Tutte le condizioni ancora aperte

1. Autorizzazione e invocazione esplicita utente di `/setup-matt-pocock-skills`. Setup, ask-matt e to-spec dichiarano tutti `disable-model-invocation: true`; la nuova sessione non elimina questa condizione.
2. Scelta/conferma del tracker consumer e del suo workflow. I link GitHub della Software Factory non costituiscono configurazione Pocock.
3. Conferma delle label predefinite oppure raccolta degli override. `triage` è registrata/configurata: il setup prevede la sezione label, con ruoli needs-triage, needs-info, ready-for-agent, ready-for-human, wontfix.
4. Layout e regole consumer dei domain docs. Il default originale è single-context; multi-context richiede segnali monorepo e conferma. Nessuna nuova glossary/ADR è un requisito universale.
5. Presentazione dei draft e conferma prima di scrivere; produzione di `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`, `docs/agents/domain.md` e aggiornamento del blocco Agent skills nel file scelto secondo il setup originale. I tre input sono assenti; nessun equivalente è fornito dalla richiesta. Nessun passo di setup viene eseguito qui.
6. Successiva invocazione utente `/to-spec` con scope esplicito di sintesi/pubblicazione, contesto sorgente adeguato, uso della glossary e rispetto degli ADR pertinenti se esistenti. Non è richiesta approvazione di una spec ancora non scritta.
7. Conferma reale del seam secondo `/to-spec` e autorità applicabile. seam-approved resta solo input discriminatore; non sostituisce setup o approvazione Product Owner.
8. Regole di contesto e dipendenze prima di tickets/implementazione: ask-matt richiede steps 1–3 nello stesso contesto ininterrotto fino a `/to-tickets`, salvo compact al confine secondo le sue regole. Questo processo fresh non ne prova la continuità e non autorizza un percorso alternativo.
9. Risultati worker/TDD/runtime/integrazione/review Pocock, inventario completo e closeout di profilo restano non dimostrati. La correzione dei puntatori routing non colma queste lacune.
10. Pilot reale selezionato e autorizzato, CI reale, review/check sulla revisione finale, autorità PR/merge non specificati, merge SHA, smoke post-merge, release e distinto OK deployment restano mancanti/non dimostrati. Non sono gate per questa sola ispezione. Nessuna attestazione di CI verde, delivery o missione chiusa.

## Deduzione indipendente e prossima azione

**Fatti:** root senza docs/; nessuna configurazione equivalente nella richiesta; ask-matt impone setup prima del primo flow engineering; to-spec rimanda al setup se tracker/label non sono forniti; autorizzazione corrente limitata a ispezione/report. **Deduzione:** la sintesi/pubblicazione resta bloccata sia dal setup mancante sia dallo scope, indipendentemente da seam-approved e dal recupero dei raw.

**Prossima azione consentita ora:** consegnare questo report. Per avanzare il prodotto occorrono congiuntamente autorizzazione e invocazione utente del setup, completamento delle scelte/conferme e degli output; poi invocazione user-only `/to-spec` autorizzata alla sintesi/pubblicazione, contesto conforme alle fonti e conferma reale del seam. I passi successivi mantengono dipendenze e gate propri. Nessuna azione viene delegata o avviata automaticamente.

## Dati esaminati e limiti

Letti: MISSION integralmente anche raw, SPEC-team-execution, tasks/plan, REQ-0001, RFC-0001 nelle due porzioni 1–260 e 264–421, config locale completa, root completa, precedente RECOVERY. AGENTS era fornito nel contesto. Letti originali via `skill://ask-matt`, `skill://to-spec` e file setup upstream; letto anche ask-matt/PHASE-BOUNDARIES.md. Le URI sono letture autorizzate di definizioni, non esecuzione dei workflow.

Dei due JSONL routing: letti header/inizio e selezioni strutturate dei risultati bash e del fallimento resolver; della sessione canonica anche il prompt utente originale. Una selezione ampia dei toolResult è stata limitata dall'output; non si dichiara lettura integrale dei transcript. La prova rilevante è stata estratta successivamente con filtro mirato non troncato. Il primo raw recovery è solo un puntatore recuperato, non una prova letta.

Recovery **artifact-only** in un processo nuovo, senza resume o chat implementer. Leggere una sessione salvata come file non è history-bearing resume: non ripristina conversazioni child live, liveness o un unico context window Pocock continuo. Un resume con cronologia sarebbe una verifica distinta, non esercitata.

Verifica per ispezione della correzione: **SÌ**; prosecuzione engineering: **NO**, richiede le condizioni sopra. Nessun test verde invariato rieseguito, spawn, git write, rete/xd, installazione, provider fallback/retry, modifica sorgente/config/auth/globale/altri repository. Unico documento aggiornato: `RECOVERY.md`; nessuna fonte autorevole modificata o archiviata. La missione complessiva resta aperta.
