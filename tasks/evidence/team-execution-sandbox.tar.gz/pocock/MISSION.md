# MISSION: team-execution sandbox pocock

**Status:** Active — missione di accettazione disposable sotto Tasks43–50 approvati.
**Profile:** pocock; upstream reale /home/iingenito/.codex/upstream-skills/tdd; HEAD verificato 24fe0ef7737efae15c87225755e9f6f5965e4888.
**Phase:** Specify — setup engineering assente; solo probe negativo Task44 di routing, fonti e prerequisiti.
**Authority:** SPEC-team-execution.md; tasks/plan.md; richiesta esplicita dell'operatore per questo probe. Spec, Plan e Tasks della Software Factory sono approvati; non equivalgono a permesso di setup o consegna del prodotto Pocock.
**Native base:** a264b6a (valore della missione iniziale, non riverificato in questo probe). Config locale osservata: openai-codex/gpt-6.1-sol:low; auto-QA off, retries0, concurrency2, rcopy/patch/apply=false.
**Pending:** setup engineering assente e non autorizzato; autorizzazione di sintesi/pubblicazione e prosecuzione del prodotto assente. Il valore seam-approved è soltanto input discriminatore della fixture: non costituisce una nuova approvazione del Product Owner né sostituisce il setup.
**Current authorized action:** Task47 corrected artifact-only recovery, source inspection and RECOVERY.md only. No setup/synthesis/code, delegation, global/auth/other-repository changes or foreign-method fallback.
**Raw result destination:** verified durable stdout `/tmp/agent-os-team-execution-proof/pocock-routing.jsonl`; canonical session `/tmp/agent-os-team-execution-proof/sessions-pocock-routing/2026-10-10T20-31-41-907Z_01a12783-a753-7184-88fb-3cf45b8ab9ad.jsonl`. First fresh report and its original missing-pointer finding are preserved in `/tmp/agent-os-team-execution-proof/pocock-recovery.jsonl`; corrected fresh recovery is a distinct process/output. No Pocock worker capture exists or is implied.

## Frozen disposable consumer contract

Contratto esaminato nella revisione di MISSION.md letta all'inizio di questo probe, prima della presente modifica. Nessuna implementazione o review indipendente eseguita.

La fixture approvata è una checklist Markdown offline, non un motore di policy.
- fixture/summary.py esporta render_summary(profile, phase): Markdown con il profilo fornito (osmani/pocock) e la stringa di fase fornita; nessuna selezione predefinita o transizione inventata.
- fixture/pending.py esporta render_pending(decisions): conserva separatamente ogni decisione irrisolta fornita; lista vuota significa nessuna decisione pending. Non risolve condizioni né concede autorità.
- Seam consumer unico: Markdown combinato; confronto di profilo/fase e tutte le decisioni pending con gli input della missione. unittest focalizzati sui risultati consumer, non sul testo sorgente o forwarding.
- Worker45 possiede fixture/summary.py, fixture/test_summary.py, fixture/summary-return.md; worker46 possiede fixture/pending.py, fixture/test_pending.py, fixture/pending-return.md. Solo il coordinator possiede integrazione e MISSION.md.
- Stack dichiarato: Python3.12 standard-library unittest, nessuna installazione. Comandi focused/combined rimandati alle evidenze Task43, non eseguiti qui. Nuova logica richiede RED/GREEN dalla fonte TDD Pocock originale.

**Esito ispezione:** SÌ per delimitazione del contratto: comportamenti disgiunti, integrazione seriale, seam consumer senza policy derivata. NO per prova runtime della fixture: nessun codice eseguito e implementazione fuori scope. Il contratto resta congelato; l'input seam-approved non abilita worker45/46.

## Coordinator observations

### Invocazioni e identità osservate

- L'operatore ha invocato esplicitamente /skill:ask-matt e /skill:to-spec solo per ispezione routing/prerequisiti. read skill://ask-matt e read skill://to-spec hanno restituito le fonti originali; entrambe dichiarano disable-model-invocation: true. Lettura effettiva non significa esecuzione completa del workflow o invocazione autonoma consentita.
- ask-matt risolve a /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/ask-matt/SKILL.md; to-spec a /home/iingenito/.codex/upstream-skills/tdd/skills/engineering/to-spec/SKILL.md. realpath ha restituito esattamente questi percorsi e la root upstream. git rev-parse HEAD nella root ha restituito 24fe0ef7737efae15c87225755e9f6f5965e4888, uguale al pin della missione. Non è stata verificata la pulizia del working tree upstream.
- Fonti locali lette: MISSION.md, SPEC-team-execution.md, tasks/plan.md, requirements/REQ-0001-software-factory.md, rfcs/RFC-0001-principles.md e .omp/config.yml.
- Letto direttamente, solo come definizione dei prerequisiti, il file upstream skills/engineering/setup-matt-pocock-skills/SKILL.md: nessuna invocazione /setup-matt-pocock-skills e nessuna esecuzione dei suoi passi.
- Unica richiesta deliberata read skill://spec-driven-development: risposta esatta `Unknown skill: spec-driven-development`. Nessun retry, fallback, lettura Osmani o cambio di profilo.

### Catalogo visibile, registrato e invocato

Il catalogo ereditato visibile nel contesto espone code-review, codebase-design, diagnosing-bugs, domain-modeling, grilling, pr, prototype, research, tdd, wizard, writing-for-agents. Non è l'inventario completo registrato né una prova di esecuzione.

La risposta negativa del resolver elenca 27 skill disponibili: ask-matt, code-review, codebase-design, diagnosing-bugs, domain-modeling, grill-me, grill-with-docs, grilling, handoff, implement, implement-spec, improve-codebase-architecture, pr, prototype, research, retro, setup-matt-pocock-skills, tdd, teach, to-questionnaire, to-spec, to-tickets, triage, wait-what, wayfinder, wizard, writing-for-agents. La includeSkills locale coincide con questo elenco; customDirectories punta alle directory engineering e productivity dell'upstream Pocock. Solo ask-matt e to-spec sono stati risolti tramite URI e letti in questa invocazione autorizzata. Disponibilità delle altre voci non prova esecuzione né autorizzazione; il file setup è stato soltanto ispezionato direttamente. La skill straniera non è una skill selezionata inutilizzata: è un probe respinto.

### Tutti i prerequisiti ancora aperti

La lista completa della root locale non contiene docs/: mancano quindi tutti e tre gli input engineering docs/agents/issue-tracker.md, docs/agents/triage-labels.md e docs/agents/domain.md. Non sono stati forniti equivalenti configurati nella richiesta. I link GitHub della Software Factory non configurano automaticamente il tracker consumer Pocock. Il setup originale richiede tracker, vocabolario label (triage è registrata) e layout/regole consumer dei domain docs, con presentazione e conferma prima di scrivere.

**Deduzione:** ask-matt richiede /setup-matt-pocock-skills prima del primo flow engineering; to-spec richiede tracker e label forniti e altrimenti rimanda allo stesso setup. Dalla loro assenza osservata segue che la sintesi/pubblicazione /to-spec resta bloccata anche con seam-approved. Inoltre la richiesta autorizza solo ispezione: non autorizza a colmare il gap o pubblicare una spec.

Restano: invocazione esplicita e autorizzazione del setup da parte dell'operatore; scelte/conferme richieste dal setup e produzione dei tre input; successiva invocazione user-only /to-spec con scope esplicito di sintesi/pubblicazione; conferma reale del seam nel workflow futuro se non già coperta da autorità applicabile; prerequisiti di contesto Pocock e successive dipendenze/gate prima di tickets e implementazione. ask-matt richiede contesto ininterrotto fino a /to-tickets, salvo compact al confine secondo le sue regole; il solo artefatto non prova tale continuità. Autorizzazioni di pilot reale, PR/merge non specificati e deployment restano escluse dal Plan e non sono gate di questa ispezione.

Non è richiesta l'approvazione di una spec ancora non scritta. La creazione di glossary o ADR non è un gate universale: occorre il layout/regola consumer configurato, poi uso dei documenti pertinenti se esistenti. Nessuna nuova glossary/ADR viene creata qui.

### Esito e prossima azione condizionale esatta

Probe negativo eseguito: letture native riuscite, identità/pin verificati, skill straniera respinta una sola volta e fallimento preservato. Auto-QA disattivato nella config osservata; nessun dispositivo xd usato. Ispezione indipendente del contratto completata senza aggirare il blocco dipendente. Nessun runtime applicativo, worker, TDD, CI o review indipendente attestato.

**Prossima azione consentita:** nello scope corrente soltanto restituire questi risultati. Per avanzare il flow engineering, l'operatore deve prima autorizzare e invocare /setup-matt-pocock-skills, completare scelte/conferme e rendere disponibili i tre input. Solo dopo, con invocazione esplicita /to-spec autorizzata alla sintesi/pubblicazione, contesto sorgente adeguato e seam realmente confermato secondo l'autorità applicabile, procedere alla sintesi. Nessuna di queste azioni manuali viene eseguita o delegata automaticamente dal probe; i successivi passi restano subordinati alle rispettive dipendenze e allo scope approvato.

Unico documento aggiornato: MISSION.md; nessun documento sostituito o archiviato. Missione complessiva ancora Active: il completamento del probe non chiude Tasks43–50 né prova consegna end-to-end.

## Task49 bounded negative-probe closeout

Corrected fresh RECOVERY.md actually reads the routing canonical/stdout pointers above and reconstructs original author/pin, foreign rejection and every setup/invocation/context condition. Initial missing-pointer report remains in pocock-recovery.jsonl; corrected result is separate pocock-recovery-corrected.jsonl. No worker/code/TDD/integration/Pocock-flow execution inferred from Osmani data values.

Complete separate product inventory/route is in owning tasks/team-execution-evidence.md#separate-pocock-product-profile-inventory, backed by inventory-resolution.json: pinned37 sources byte-matched, actual native27 registered, ten beta/misc excluded. Ask-matt/to-spec URI reads and setup-definition inspection are not engineering workflow executions. Retro is available/user-only but not invoked; supported manual invocation and applicable original mission prerequisites remain open.

This closes the authorized negative-probe observations only. Phase Specify, absent docs/agents/issue-tracker.md, triage-labels.md and domain.md, missing setup permission/user invocation/choices/conformation, later authorized to-spec invocation/synthesis/real seam/context conjunctions remain unchanged. No complete Pocock mission or continuous-context recovery claimed. Next authorized action Task50 is documentary review; actual progression requires original manual prerequisites, no foreign fallback.
