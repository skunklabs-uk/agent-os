import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Parent assigns provenance from the exact production build being exercised.
const source = process.env.PROOF_SOURCE;
const sha = process.env.PROOF_SOURCE_SHA;
const buildId = process.env.PROOF_BUILD_ID;
const digest = process.env.PROOF_BUILD_FILES_SHA256;
assert.ok(source && /^[a-f0-9]{40}$/.test(sha ?? '') && buildId && /^[a-f0-9]{64}$/.test(digest ?? ''), 'Missing final source/build provenance');
const scenario = process.env.PROOF_SCENARIO ?? 'ordinary';
assert.ok(['ordinary', 'startup'].includes(scenario), 'Unknown proof scenario');
assert.equal(execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), sha);
const build = join(source, '.next-mission35');
assert.equal((await readFile(join(build, 'BUILD_ID'), 'utf8')).trim(), buildId);
assert.equal(createHash('sha256').update(await readFile(join(build, 'required-server-files.json'))).digest('hex'), digest);
assert.equal(JSON.parse(await readFile(join(source, 'node_modules/@oh-my-pi/pi-coding-agent/package.json'), 'utf8')).version, '18.8.7');
const root = dirname(fileURLToPath(import.meta.url));
process.umask(0o077);
const run = await mkdtemp(join(tmpdir(), 'mission35-proof.'));
for (const path of ['home', 'agent/extensions', 'repo/tasks', 'xdg']) await mkdir(join(run, path), { recursive: true });
const deadline = Date.now() + 240_000;
const bun = '/home/iingenito/.local/share/mise/installs/bun/1.3.14/bin/bun';
const env = {
  PATH: `${dirname(bun)}:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin`, LANG: 'C.UTF-8',
  HOME: join(run, 'home'), XDG_CONFIG_HOME: join(run, 'xdg'), XDG_CACHE_HOME: join(run, 'xdg'), XDG_RUNTIME_DIR: join(run, 'xdg'),
  PI_CODING_AGENT_DIR: join(run, 'agent'), OMP_WEB_AUTH_SOURCE_DIR: join(run, 'agent'),
  NODE_ENV: 'production', NEXT_TELEMETRY_DISABLED: '1', PI_AUTO_QA: '0', PI_CODEX_WEBSOCKET: '0', AWS_EC2_METADATA_DISABLED: 'true',
  GIT_CONFIG_NOSYSTEM: '1', NO_PROXY: '127.0.0.1,localhost', no_proxy: '127.0.0.1,localhost',
  OMP_WEB_DIST_DIR: '.next-mission35', OMP_WEB_HOSTNAME: '127.0.0.1',
  OMP_WEB_ACCESS_TEAM_DOMAIN: 'https://mission35-proof.cloudflareaccess.com', OMP_WEB_ACCESS_AUD: 'mission35-local-proof-only',
  OMP_WEB_PUBLIC_ORIGIN: 'https://mission35-proof.invalid',
  AGENT_OS_MISSION_ID: 'example/disposable#35', AGENT_OS_MISSION_CWD: join(run, 'repo'),
  PROOF_SOURCE: source, PROOF_SOURCE_SHA: sha, PROOF_BUILD_ID: buildId, PROOF_BUILD_FILES_SHA256: digest,
  PROOF_RUN: run, PROOF_DEADLINE: String(deadline), PROOF_SCENARIO: scenario,
};
// No inherited credentials, proxy settings, browser process or unavailable namespace operation.
const child = spawn(bun, [join(root, 'native.mjs')], { env, cwd: source, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
let log = '';
child.stdout.on('data', bytes => { log += bytes.toString(); });
child.stderr.on('data', bytes => { log += bytes.toString(); });
child.once('error', error => { log += `${error.stack}\n`; });
const finished = new Promise(resolve => {
  child.once('exit', (code, signal) => resolve({ code, signal }));
  child.once('error', () => resolve({ code: 1, signal: null }));
});
let ended = false;
let forced = false;
function terminate() {
  if (ended || forced) return;
  forced = true;
  try { process.kill(-child.pid, 'SIGTERM'); } catch {}
  setTimeout(() => { try { process.kill(-child.pid, 'SIGKILL'); } catch {} }, 1800).unref();
}
const timer = setTimeout(terminate, Math.max(1, deadline - Date.now() - 2000));
process.on('SIGTERM', terminate); process.on('SIGINT', terminate);
try {
  await writeFile(join(root, 'current-run.txt'), run + '\n', { mode: 0o600 });
  console.log(JSON.stringify({ run, scenario, deadline, provenance: { sha, buildId, digest } }));
  const result = await finished;
  // The native process has completed its journal/Next cleanup. Kill only leftover owned descendants.
  try { process.kill(-child.pid, 'SIGKILL'); } catch {}
  ended = true;
  // Also cover failures before native cleanup was installed and hard deadline kills.
  await rm(join(run, 'assertion.txt'), { force: true });
  await rm(join(run, 'agent', 'extensions', 'mission35-startup.js'), { force: true });
  await writeFile(join(run, 'launch.log'), log, { mode: 0o600 });
  process.exitCode = forced ? 124 : (result.code ?? 1);
} finally {
  clearTimeout(timer);
  if (!ended) terminate();
}
